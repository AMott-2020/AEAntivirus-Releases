#!/bin/sh
# AEAntivirus macOS daemon build script.
#
# Builds ./aeantivirusd on a Mac with Xcode command line tools.
# No extra dependencies: clang + the system libcurl that ships with macOS.
#
#   ./build.sh        (run from the macos/ directory)
#
# If the tools are missing, install them first:
#   xcode-select --install
set -eu

cd "$(dirname "$0")/daemon"

if ! xcode-select -p >/dev/null 2>&1; then
    echo "ERROR: Xcode command line tools not found." >&2
    echo "Install them with:  xcode-select --install" >&2
    exit 1
fi

CC="${CC:-clang}"
"$CC" -O2 -Wall -Wextra -std=c11 -o aeantivirusd aeantivirusd.c sha256.c -lcurl

echo "Built ./aeantivirusd"
./aeantivirusd --version
