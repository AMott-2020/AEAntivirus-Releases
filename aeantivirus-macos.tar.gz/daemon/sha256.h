/*
 * sha256.h — public domain SHA-256 (Brad Conte "crypto-algorithms" style).
 *
 * Single-file, no dependencies beyond the C standard library.
 * Used by aeantivirusd to hash files for signature matching and to
 * verify downloaded updates.
 */
#ifndef AEANTIVIRUS_SHA256_H
#define AEANTIVIRUS_SHA256_H

#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint8_t  data[64];
    uint32_t datalen;
    uint64_t bitlen;
    uint32_t state[8];
} SHA256_CTX;

void sha256_init(SHA256_CTX *ctx);
void sha256_update(SHA256_CTX *ctx, const uint8_t *data, size_t len);
void sha256_final(SHA256_CTX *ctx, uint8_t hash[32]);

/* Convenience: hex-encode a 32-byte digest into a 64-char + NUL string. */
void sha256_to_hex(const uint8_t hash[32], char out_hex[65]);

/* Hash a whole file; writes 64 hex chars + NUL to out_hex.
 * Returns 0 on success, -1 on I/O error. */
int sha256_file(const char *path, char out_hex[65]);

#endif /* AEANTIVIRUS_SHA256_H */
