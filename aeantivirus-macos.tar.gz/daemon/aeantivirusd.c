/* aeantivirusd.c - AEAntivirus protection daemon for macOS.
 *
 * Version 1.15.0. Feature parity with the Linux aeantivirusd client:
 *   - Runs as root via launchd (/Library/LaunchDaemons/com.aeantivirus.daemon.plist)
 *   - Periodic polling sweep (default every 15 min, configurable) of /tmp,
 *     /var/tmp and every /Users/<name>/{Downloads,Desktop} plus /Users/Shared
 *   - On-demand CLI scans (single file, directory, or multiple paths)
 *   - Scan engine: SHA-256 vs signatures.db + heuristic engine
 *     (double extensions, suspicious Mach-O binaries, suspicious shell scripts,
 *     EICAR test file)
 *   - Quarantine with .meta records, list/restore/delete CLI
 *   - Cloud sync via libcurl HTTPS POST (register / heartbeat / detection)
 *   - Engine + signature updates from /updates/manifest-macos.json
 *   - License enforcement with 72h past-due grace
 *   - Logging to syslog (LOG_DAEMON), or stderr in foreground/CLI mode
 *
 * HONEST v1 SCOPE: this daemon does NOT do realtime on-access scanning.
 * True on-access protection on macOS requires an EndpointSecurity system
 * extension, Apple Developer approval, and user consent in System Settings -
 * that is a future release. v1 detects threats on its periodic sweep and
 * on manual scans. See ../README.md ("What v1 does NOT do").
 *
 * PORTABILITY: all Apple-specific code is inside #ifdef __APPLE__ blocks
 * (launchd-based restart after an engine update). Everything else is
 * portable POSIX C11 and must keep passing:
 *     gcc -fsyntax-only -Wall -Wextra -std=c11 aeantivirusd.c sha256.c
 * on Linux (libcurl headers can be stubbed for the syntax check).
 *
 * Build on a Mac:  ../build.sh   (Xcode command line tools, no extra deps)
 *
 * NOTE: never compiled or run on macOS yet (see ../README.md). Do not ship
 * to customers without building and testing on real macOS hardware.
 */

/* Exposes timegm/strptime prototypes on glibc; ignored on macOS. */
#define _GNU_SOURCE

#include <ctype.h>
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <syslog.h>
#include <time.h>
#include <unistd.h>

#include <curl/curl.h>

/* PATH_MAX is in <limits.h> on macOS; guard for oddball environments. */
#ifndef PATH_MAX
#  ifdef MAXPATHLEN
#    define PATH_MAX MAXPATHLEN
#  else
#    define PATH_MAX 4096
#  endif
#endif

#include "sha256.h"

/* ------------------------------------------------------------------ */
/* Constants                                                           */
/* ------------------------------------------------------------------ */

#define VERSION          "1.15.0"
#define PLATFORM         "macos"

#define APP_SUPPORT_DEF  "/Library/Application Support/AEAntivirus"
#define INSTALL_BIN      "/usr/local/libexec/aeantivirus/aeantivirusd"
#define PLIST_LABEL      "com.aeantivirus.daemon"
#define PLIST_PATH       "/Library/LaunchDaemons/com.aeantivirus.daemon.plist"
#define MANIFEST_PATH    "/updates/manifest-macos.json"
#define DEFAULT_SERVER   "https://aeantivirus.com"

#define MAX_PATH         4096
#define HASH_HEX         64
#define MAX_SIGS         65536
#define MAX_SCAN_BYTES   (512UL * 1024UL * 1024UL)  /* skip files > 512 MB */
#define SCAN_HEAD        (256 * 1024)

#define HEARTBEAT_SECS   (15 * 60)
#define UPDATE_SECS      (6 * 3600)
#define FULLSCAN_SECS    (7 * 24 * 3600)
#define GRACE_SECS       (72 * 3600)                /* past-due grace window */
#define DEFAULT_SCAN_MIN 15                          /* polling sweep interval */

static int g_foreground = 0;   /* log to stderr instead of syslog */

/* ------------------------------------------------------------------ */
/* Paths (overridable via AEA_BASE for testing)                        */
/* ------------------------------------------------------------------ */
static char g_appDir[MAX_PATH];    /* /Library/Application Support/AEAntivirus */
static char g_cfgFile[MAX_PATH];
static char g_sigFile[MAX_PATH];
static char g_quarDir[MAX_PATH];
static char g_statsFile[MAX_PATH];

static int mkdir_p(const char *path, mode_t mode) {
    /* recursive mkdir, no shell involved (paths may contain spaces) */
    char tmp[MAX_PATH];
    snprintf(tmp, sizeof(tmp), "%s", path);
    size_t len = strlen(tmp);
    if (len == 0) return -1;
    if (tmp[len - 1] == '/') tmp[len - 1] = 0;
    for (char *p = tmp + 1; *p; p++) {
        if (*p == '/') {
            *p = 0;
            if (mkdir(tmp, mode) != 0 && errno != EEXIST) return -1;
            *p = '/';
        }
    }
    if (mkdir(tmp, mode) != 0 && errno != EEXIST) return -1;
    return 0;
}

static void init_paths(void) {
    const char *base = getenv("AEA_BASE");
    if (base && *base) {
        snprintf(g_appDir, sizeof(g_appDir), "%s", base);
    } else {
        snprintf(g_appDir, sizeof(g_appDir), "%s", APP_SUPPORT_DEF);
    }
    snprintf(g_cfgFile, sizeof(g_cfgFile), "%s/config", g_appDir);
    snprintf(g_sigFile, sizeof(g_sigFile), "%s/signatures.db", g_appDir);
    snprintf(g_quarDir, sizeof(g_quarDir), "%s/quarantine", g_appDir);
    snprintf(g_statsFile, sizeof(g_statsFile), "%s/stats", g_appDir);
}

static int mkdirs(void) {
    if (mkdir_p(g_appDir, 0755) != 0) return -1;
    if (mkdir_p(g_quarDir, 0700) != 0) return -1;
    return 0;
}

/* ------------------------------------------------------------------ */
/* Logging                                                             */
/* ------------------------------------------------------------------ */
static void log_init(void) {
    if (!g_foreground) openlog("aeantivirusd", LOG_PID, LOG_DAEMON);
}
static void log_msg(int pri, const char *fmt, ...) {
    char buf[2048]; va_list ap;
    va_start(ap, fmt); vsnprintf(buf, sizeof(buf), fmt, ap); va_end(ap);
    if (g_foreground) {
        const char *tag = pri == LOG_ERR ? "ERR" : pri == LOG_WARNING ? "WARN" : "INF";
        fprintf(stderr, "[aeantivirusd:%s] %s\n", tag, buf);
    } else syslog(pri, "%s", buf);
}
#define LOGI(...) log_msg(LOG_INFO, __VA_ARGS__)
#define LOGW(...) log_msg(LOG_WARNING, __VA_ARGS__)
#define LOGE(...) log_msg(LOG_ERR, __VA_ARGS__)

/* ------------------------------------------------------------------ */
/* Tiny key=value config                                                */
/* ------------------------------------------------------------------ */
#define CFG_MAX 8192
static char g_cfg[CFG_MAX];

static void cfg_load(void) {
    memset(g_cfg, 0, sizeof(g_cfg));
    FILE *f = fopen(g_cfgFile, "r");
    if (!f) return;
    size_t nr = fread(g_cfg, 1, sizeof(g_cfg) - 1, f);
    g_cfg[nr < sizeof(g_cfg) - 1 ? nr : sizeof(g_cfg) - 1] = 0;
    fclose(f);
}
/* NOTE: returns one of 4 rotating static buffers so a few cfg_get() results
 * can be alive at once (e.g. install_id + token in the same call). */
static const char *cfg_get(const char *key) {
    static char vals[4][1024];
    static int slot = 0;
    char *val = vals[slot];
    slot = (slot + 1) % 4;
    val[0] = 0;
    size_t klen = strlen(key);
    const char *p = g_cfg;
    while ((p = strstr(p, key)) != NULL) {
        if ((p == g_cfg || p[-1] == '\n') && p[klen] == '=') {
            const char *v = p + klen + 1;
            size_t i = 0;
            while (*v && *v != '\n' && *v != '\r' && i + 1 < sizeof(vals[0]))
                val[i++] = *v++;
            val[i] = 0;
            return val;
        }
        p += klen;
    }
    return "";
}
static void cfg_set(const char *key, const char *val) {
    /* rewrite file without the key, then append */
    char out[CFG_MAX]; out[0] = 0;
    size_t klen = strlen(key);
    const char *p = g_cfg;
    char line[1100];
    while (*p) {
        const char *e = strchr(p, '\n');
        size_t ll = e ? (size_t)(e - p) : strlen(p);
        if (ll >= sizeof(line)) ll = sizeof(line) - 1;
        memcpy(line, p, ll); line[ll] = 0;
        if (!(strncmp(line, key, klen) == 0 && line[klen] == '=')) {
            strncat(out, line, sizeof(out) - strlen(out) - 2);
            strncat(out, "\n", sizeof(out) - strlen(out) - 1);
        }
        p = e ? e + 1 : p + ll;
        if (!e) break;
    }
    snprintf(out + strlen(out), sizeof(out) - strlen(out), "%s=%s\n", key, val);
    FILE *f = fopen(g_cfgFile, "w");
    if (f) { fputs(out, f); fclose(f); chmod(g_cfgFile, 0600); }
    cfg_load();
}

/* ------------------------------------------------------------------ */
/* Stats                                                               */
/* ------------------------------------------------------------------ */
static long g_scanned = 0, g_detected = 0;
static char g_lastQuick[64] = "", g_lastFull[64] = "";

static void stats_load(void) {
    FILE *f = fopen(g_statsFile, "r");
    if (!f) return;
    char line[256];
    while (fgets(line, sizeof(line), f)) {
        if (sscanf(line, "scanned=%ld", &g_scanned) == 1) continue;
        if (sscanf(line, "detected=%ld", &g_detected) == 1) continue;
        if (sscanf(line, "last_quick=%63s", g_lastQuick) == 1) continue;
        if (sscanf(line, "last_full=%63s", g_lastFull) == 1) continue;
    }
    fclose(f);
}
static void stats_save(void) {
    FILE *f = fopen(g_statsFile, "w");
    if (!f) return;
    fprintf(f, "scanned=%ld\ndetected=%ld\nlast_quick=%s\nlast_full=%s\n",
            g_scanned, g_detected, g_lastQuick, g_lastFull);
    fclose(f);
}
static void now_iso(char *out, size_t n) {
    time_t t = time(NULL);
    struct tm tm; gmtime_r(&t, &tm);
    strftime(out, n, "%Y-%m-%dT%H:%M:%SZ", &tm);
}

/* Portable memmem (macOS libc has no memmem). */
static const void *memmem_p(const void *h, size_t hl, const void *n, size_t nl) {
    if (nl == 0) return h;
    if (hl < nl) return NULL;
    const unsigned char *hh = h, *nn = n;
    for (size_t i = 0; i + nl <= hl; i++)
        if (hh[i] == nn[0] && memcmp(hh + i, nn, nl) == 0)
            return hh + i;
    return NULL;
}

/* ------------------------------------------------------------------ */
/* Signature database                                                  */
/* ------------------------------------------------------------------ */
typedef struct SigNode { char hash[HASH_HEX+1]; char name[128]; struct SigNode *next; } SigNode;
static SigNode *g_sigs = NULL;
static int g_sigCount = 0;

static void sig_add(const char *hash, const char *name) {
    if (strlen(hash) != HASH_HEX) return;
    if (g_sigCount >= MAX_SIGS) return;
    SigNode *s = malloc(sizeof(*s));
    if (!s) return;
    strncpy(s->hash, hash, sizeof(s->hash) - 1); s->hash[sizeof(s->hash)-1] = 0;
    for (char *p = s->hash; *p; ++p) *p = tolower((unsigned char)*p);
    strncpy(s->name, name, sizeof(s->name) - 1); s->name[sizeof(s->name)-1] = 0;
    s->next = g_sigs; g_sigs = s; g_sigCount++;
}
static void sig_add_builtin(void) {
    /* EICAR standard test file (harmless) — lets anyone verify detection. */
    sig_add("275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f",
            "EICAR-Test-File");
}
static void sig_load_file(void) {
    FILE *f = fopen(g_sigFile, "r");
    if (!f) return;
    char line[512];
    while (fgets(line, sizeof(line), f)) {
        line[strcspn(line, "\r\n")] = 0;
        if (strlen(line) < HASH_HEX + 2 || line[0] == '#') continue;
        char hash[HASH_HEX+1]; char name[128] = "Generic.Malware";
        memcpy(hash, line, HASH_HEX); hash[HASH_HEX] = 0;
        int ok = 1;
        for (int i = 0; i < HASH_HEX; i++)
            if (!isxdigit((unsigned char)hash[i])) { ok = 0; break; }
        if (!ok) continue;
        char *sep = line + HASH_HEX;
        while (*sep == ' ' || *sep == '\t' || *sep == '=' || *sep == ':') sep++;
        if (*sep) { snprintf(name, sizeof(name), "%s", sep); }
        sig_add(hash, name);
    }
    fclose(f);
}
static void sig_clear(void) {
    SigNode *s = g_sigs;
    while (s) { SigNode *n = s->next; free(s); s = n; }
    g_sigs = NULL; g_sigCount = 0;
}
static const char *sig_lookup(const char *hex) {
    for (SigNode *s = g_sigs; s; s = s->next)
        if (strcmp(s->hash, hex) == 0) return s->name;
    return NULL;
}
static void sig_write_defaults(void) {
    FILE *f = fopen(g_sigFile, "r");
    if (f) { fclose(f); return; }
    f = fopen(g_sigFile, "w");
    if (!f) return;
    fputs("# AEAntivirus macOS signature database\n", f);
    fputs("# format: <sha256-hex> <threat name>   (one per line, # = comment)\n", f);
    fputs("275a021bbfb6489e54d471899f7db9d1663fc695ec2fe2a2c4538aabf651fd0f EICAR-Test-File\n", f);
    fclose(f);
}

/* ------------------------------------------------------------------ */
/* Heuristic engine                                                    */
/* ------------------------------------------------------------------ */
/* Suspicious tokens inside Mach-O binaries (byte-level checks only -
 * fully portable C, no Apple headers needed). */
static const char *SUSP_MACHO_STRINGS[] = {
    "ptrace", "task_for_pid", "AuthorizationExecuteWithPrivileges",
    "/Library/LaunchDaemons", "/Library/LaunchAgents",
    "curl http", "wget http", "base64 -d", "/dev/tcp/",
    "nc -e ", "chmod +s", "setuid(", "SecKeychain", NULL
};
static const char *SUSP_SCRIPT_PATTERNS[] = {
    "curl", "wget", "base64", "eval", "exec(", "chmod +x", "/dev/tcp",
    "mkfifo", "nc ", "ncat", "powershell", "osascript", NULL
};
static const char *DOUBLE_EXT[] = {
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".jpg", ".jpeg", ".png",
    ".gif", ".txt", ".mp3", ".mp4", ".zip", ".dmg", NULL
};
static const char *EXEC_EXT[] = {
    ".sh", ".bin", ".run", ".py", ".pl", ".exe", ".command", ".app", NULL
};

static int has_double_ext(const char *name) {
    const char *dot = strrchr(name, '.');
    if (!dot) return 0;
    for (int i = 0; EXEC_EXT[i]; i++)
        if (strcasecmp(dot, EXEC_EXT[i]) == 0) {
            /* something like x.pdf.sh -> check the part before the last ext */
            char tmp[256];
            size_t pre = (size_t)(dot - name);
            if (pre >= sizeof(tmp)) pre = sizeof(tmp) - 1;
            memcpy(tmp, name, pre); tmp[pre] = 0;
            const char *d2 = strrchr(tmp, '.');
            if (!d2) return 0;
            for (int j = 0; DOUBLE_EXT[j]; j++)
                if (strcasecmp(d2, DOUBLE_EXT[j]) == 0) return 1;
            /* any double executable-looking extension counts too */
            for (int j = 0; EXEC_EXT[j]; j++)
                if (strcasecmp(d2, EXEC_EXT[j]) == 0) return 1;
        }
    return 0;
}

/* Mach-O magic numbers (all four byte orders / fat binaries). */
static int is_macho(const unsigned char *head, size_t headlen) {
    if (headlen < 4) return 0;
    uint32_t m = ((uint32_t)head[0] << 24) | ((uint32_t)head[1] << 16) |
                 ((uint32_t)head[2] << 8) | head[3];
    return m == 0xFEEDFACE || m == 0xFEEDFACF ||   /* 32/64-bit Mach-O */
           m == 0xCAFEBABE || m == 0xCAFEBABF ||   /* fat binary */
           m == 0xCEFAEDFE || m == 0xCFFAEDFE;     /* reverse byte order */
}

/* returns threat name (static) or NULL */
static const char *heuristics(const char *path, const unsigned char *head, size_t headlen) {
    const char *base = strrchr(path, '/');
    base = base ? base + 1 : path;
    if (has_double_ext(base)) return "AI.Heuristic.Suspicious";

    int macho = is_macho(head, headlen);
    int is_script = headlen > 2 && head[0] == '#' && head[1] == '!';

    /* EICAR content check catches it regardless of trailing bytes */
    if (headlen >= 68 && memmem_p(head, headlen,
            "X5O!P%@AP[4\\PZX54(P^)7CC)7}$EICAR-STANDARD-ANTIVIRUS-TEST-FILE!$H+H*", 68))
        return "EICAR-Test-File";

    if (macho) {
        int hits = 0;
        for (int i = 0; SUSP_MACHO_STRINGS[i]; i++)
            if (memmem_p(head, headlen, SUSP_MACHO_STRINGS[i], strlen(SUSP_MACHO_STRINGS[i])))
                hits++;
        if (hits >= 2) return "AI.Heuristic.Suspicious";
    }
    if (is_script) {
        int hits = 0;
        for (int i = 0; SUSP_SCRIPT_PATTERNS[i]; i++)
            if (memmem_p(head, headlen, SUSP_SCRIPT_PATTERNS[i], strlen(SUSP_SCRIPT_PATTERNS[i])))
                hits++;
        if (hits >= 3) return "AI.Heuristic.Suspicious";
    }
    return NULL;
}

/* ------------------------------------------------------------------ */
/* File scanning                                                       */
/* ------------------------------------------------------------------ */
static const char *scan_file(const char *path) {
    struct stat st;
    if (lstat(path, &st) != 0) return NULL;
    if (!S_ISREG(st.st_mode)) return NULL;
    if (st.st_size == 0 || (unsigned long)st.st_size > MAX_SCAN_BYTES) return NULL;

    char hex[HASH_HEX + 1];
    if (sha256_file(path, hex) != 0) return NULL;
    const char *hit = sig_lookup(hex);
    if (hit) return hit;

    /* read head for heuristics */
    FILE *f = fopen(path, "rb");
    if (!f) return NULL;
    size_t n = (unsigned long)st.st_size < SCAN_HEAD ? (size_t)st.st_size : SCAN_HEAD;
    unsigned char *buf = malloc(n ? n : 1);
    if (!buf) { fclose(f); return NULL; }
    size_t got = fread(buf, 1, n, f);
    fclose(f);
    const char *h = heuristics(path, buf, got);
    free(buf);
    return h;
}

/* quarantine: move file aside + metadata. Returns id (>0) on success. */
static long g_quarSeq = 0;
static long quarantine_file(const char *path, const char *threat) {
    char id[32], dst[MAX_PATH], meta[MAX_PATH], iso[64];
    now_iso(iso, sizeof(iso));
    /* sequence from existing files */
    if (g_quarSeq == 0) {
        DIR *d = opendir(g_quarDir);
        if (d) {
            struct dirent *e;
            while ((e = readdir(d))) {
                long v = atol(e->d_name);
                if (v > g_quarSeq) g_quarSeq = v;
            }
            closedir(d);
        }
    }
    long idn = ++g_quarSeq;
    snprintf(id, sizeof(id), "%ld", idn);
    snprintf(dst, sizeof(dst), "%s/%s", g_quarDir, id);
    snprintf(meta, sizeof(meta), "%s/%s.meta", g_quarDir, id);
    if (rename(path, dst) != 0) {
        LOGE("quarantine: cannot move %s: %s", path, strerror(errno));
        g_quarSeq--;
        return -1;
    }
    FILE *f = fopen(meta, "w");
    if (f) {
        fprintf(f, "original_path=%s\ndate=%s\nthreat=%s\n", path, iso, threat);
        fclose(f);
    }
    chmod(dst, 0600);
    LOGW("quarantine: %s -> #%ld (%s)", path, idn, threat);
    return idn;
}

/* report a detection to the server (best effort) */
static void cloud_report_detection(const char *threat, const char *path); /* fwd */

static void handle_detection(const char *path, const char *threat) {
    g_detected++;
    stats_save();
    LOGW("DETECTED %s in %s", threat, path);
    cloud_report_detection(threat, path);
    long id = quarantine_file(path, threat);
    if (id < 0) LOGE("quarantine failed for %s", path);
}

/* true if path is dir itself or underneath it (boundary-aware) */
static int path_under(const char *path, const char *dir) {
    size_t dl = strlen(dir);
    if (strncmp(path, dir, dl) != 0) return 0;
    return path[dl] == 0 || path[dl] == '/';
}

static int should_skip_path(const char *path) {
    if (path_under(path, g_quarDir)) return 1;
    if (path_under(path, "/dev")) return 1;
    if (path_under(path, "/System")) return 1;
    if (path_under(path, "/private")) return 1;
    if (path_under(path, "/Network")) return 1;
    if (path_under(path, "/Volumes")) return 1;
    return 0;
}

/* recursive scan of a directory tree */
static void scan_tree(const char *dir, int *files, int *hits) {
    DIR *d = opendir(dir);
    if (!d) return;
    struct dirent *e;
    char full[MAX_PATH];
    while ((e = readdir(d))) {
        if (strcmp(e->d_name, ".") == 0 || strcmp(e->d_name, "..") == 0) continue;
        snprintf(full, sizeof(full), "%s/%s", dir, e->d_name);
        if (should_skip_path(full)) continue;
        struct stat st;
        if (lstat(full, &st) != 0) continue;
        if (S_ISDIR(st.st_mode)) {
            scan_tree(full, files, hits);
        } else if (S_ISREG(st.st_mode)) {
            (*files)++;
            g_scanned++;
            const char *t = scan_file(full);
            if (t) { (*hits)++; handle_detection(full, t); }
        }
    }
    closedir(d);
}

/* ------------------------------------------------------------------ */
/* Cloud sync (libcurl, JSON)                                          */
/* ------------------------------------------------------------------ */
struct HttpResp { char *data; size_t len; };

static size_t curl_write(char *ptr, size_t size, size_t nmemb, void *ud) {
    struct HttpResp *r = ud;
    size_t n = size * nmemb;
    char *p = realloc(r->data, r->len + n + 1);
    if (!p) return 0;
    r->data = p;
    memcpy(r->data + r->len, ptr, n);
    r->len += n;
    r->data[r->len] = 0;
    return n;
}

/* POST JSON, returns malloc'd response body (caller frees) or NULL */
static char *http_post(const char *url, const char *json, long *out_code) {
    CURL *c = curl_easy_init();
    if (!c) return NULL;
    struct HttpResp r = { malloc(1), 0 };
    if (r.data) r.data[0] = 0;
    struct curl_slist *hdrs = NULL;
    hdrs = curl_slist_append(hdrs, "Content-Type: application/json");
    curl_easy_setopt(c, CURLOPT_URL, url);
    curl_easy_setopt(c, CURLOPT_HTTPHEADER, hdrs);
    curl_easy_setopt(c, CURLOPT_POSTFIELDS, json);
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, curl_write);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &r);
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 25L);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    /* server URL is https in production; allow http for local testing */
    CURLcode rc = curl_easy_perform(c);
    long code = 0;
    if (rc == CURLE_OK) curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &code);
    curl_slist_free_all(hdrs);
    curl_easy_cleanup(c);
    if (out_code) *out_code = code;
    if (rc != CURLE_OK) { free(r.data); return NULL; }
    return r.data;
}

static char *http_get(const char *url) {
    CURL *c = curl_easy_init();
    if (!c) return NULL;
    struct HttpResp r = { malloc(1), 0 };
    if (r.data) r.data[0] = 0;
    curl_easy_setopt(c, CURLOPT_URL, url);
    curl_easy_setopt(c, CURLOPT_WRITEFUNCTION, curl_write);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, &r);
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 60L);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    CURLcode rc = curl_easy_perform(c);
    curl_easy_cleanup(c);
    if (rc != CURLE_OK) { free(r.data); return NULL; }
    return r.data;
}

/* download a URL to a file; returns 0 on success */
static int http_download(const char *url, const char *dst) {
    CURL *c = curl_easy_init();
    if (!c) return -1;
    FILE *f = fopen(dst, "wb");
    if (!f) { curl_easy_cleanup(c); return -1; }
    curl_easy_setopt(c, CURLOPT_URL, url);
    curl_easy_setopt(c, CURLOPT_WRITEDATA, f);
    curl_easy_setopt(c, CURLOPT_TIMEOUT, 300L);
    curl_easy_setopt(c, CURLOPT_FOLLOWLOCATION, 1L);
    CURLcode rc = curl_easy_perform(c);
    long code = 0;
    if (rc == CURLE_OK) curl_easy_getinfo(c, CURLINFO_RESPONSE_CODE, &code);
    curl_easy_cleanup(c);
    fclose(f);
    if (rc != CURLE_OK || code < 200 || code >= 300) { unlink(dst); return -1; }
    return 0;
}

/* JSON helpers: escape a string for embedding; extract values by key */
static void json_escape(const char *in, char *out, size_t n) {
    size_t j = 0;
    for (size_t i = 0; in[i] && j + 6 < n; i++) {
        unsigned char c = in[i];
        if (c == '"' || c == '\\') { out[j++] = '\\'; out[j++] = c; }
        else if (c == '\n') { out[j++] = '\\'; out[j++] = 'n'; }
        else if (c == '\r') { out[j++] = '\\'; out[j++] = 'r'; }
        else if (c == '\t') { out[j++] = '\\'; out[j++] = 't'; }
        else if (c < 0x20) { j += snprintf(out + j, n - j, "\\u%04x", c); }
        else out[j++] = c;
    }
    out[j] = 0;
}
/* extract string value for "key" (handles \" escapes); returns 1 if found */
static int json_get_str(const char *json, const char *key, char *out, size_t n) {
    char pat[160];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = json;
    while ((p = strstr(p, pat)) != NULL) {
        const char *q = p + strlen(pat);
        while (*q == ' ' || *q == '\t') q++;
        if (*q != ':') { p += strlen(pat); continue; }
        q++;
        while (*q == ' ' || *q == '\t') q++;
        if (*q != '"') { p += strlen(pat); continue; }
        q++;
        size_t j = 0;
        while (*q && *q != '"' && j + 1 < n) {
            if (*q == '\\' && q[1]) {
                q++;
                if (*q == 'n') out[j++] = '\n';
                else if (*q == 'r') out[j++] = '\r';
                else if (*q == 't') out[j++] = '\t';
                else out[j++] = *q;
                q++;
            } else out[j++] = *q++;
        }
        out[j] = 0;
        return 1;
    }
    return 0;
}
static long json_get_long(const char *json, const char *key) {
    char pat[160];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = json;
    while ((p = strstr(p, pat)) != NULL) {
        const char *q = p + strlen(pat);
        while (*q == ' ' || *q == '\t') q++;
        if (*q != ':') { p += strlen(pat); continue; }
        q++;
        while (*q == ' ' || *q == '\t') q++;
        return atol(q);
    }
    return 0;
}
static int json_get_bool(const char *json, const char *key) {
    /* handles "key":true / "key":false / "key":1 / "key":"1" */
    char pat[160];
    snprintf(pat, sizeof(pat), "\"%s\"", key);
    const char *p = json;
    while ((p = strstr(p, pat)) != NULL) {
        const char *q = p + strlen(pat);
        while (*q == ' ' || *q == '\t') q++;
        if (*q != ':') { p += strlen(pat); continue; }
        q++;
        while (*q == ' ' || *q == '\t') q++;
        if (*q == '"') {
            char v[32];
            if (json_get_str(json, key, v, sizeof(v))) return atoi(v) != 0;
            return 0;
        }
        if (strncmp(q, "true", 4) == 0) return 1;
        if (strncmp(q, "false", 5) == 0) return 0;
        return atol(q) != 0;
    }
    return 0;
}

static void server_url(char *out, size_t n) {
    const char *u = cfg_get("server_url");
    if (!*u) u = DEFAULT_SERVER;
    strncpy(out, u, n - 1); out[n-1] = 0;
    /* strip trailing slash */
    size_t l = strlen(out);
    while (l > 0 && out[l-1] == '/') out[--l] = 0;
}
static void get_hostname(char *out, size_t n) {
    if (gethostname(out, n) != 0) strncpy(out, "mac", n);
    out[n-1] = 0;
}

/* ---------------- register ---------------- */
static int cloud_register(void) {
    char url[MAX_PATH + 32], srv[MAX_PATH];
    server_url(srv, sizeof(srv));
    snprintf(url, sizeof(url), "%s/api/register", srv);
    char host[256], lk[128], esc_h[512], esc_k[256];
    get_hostname(host, sizeof(host));
    strncpy(lk, cfg_get("license_key"), sizeof(lk) - 1);
    json_escape(host, esc_h, sizeof(esc_h));
    json_escape(lk, esc_k, sizeof(esc_k));
    char body[2048];
    snprintf(body, sizeof(body),
             "{\"license_key\":\"%s\",\"hostname\":\"%s\",\"version\":\"%s\",\"platform\":\"%s\"}",
             esc_k, esc_h, VERSION, PLATFORM);
    long code = 0;
    char *resp = http_post(url, body, &code);
    if (!resp) { LOGW("cloud: register failed (offline?)"); return -1; }
    int ok = json_get_bool(resp, "ok");
    if (!ok) {
        char err[256] = "";
        json_get_str(resp, "error", err, sizeof(err));
        LOGE("cloud: register rejected: %s", err);
        free(resp);
        return -2;
    }
    char iid[64] = "", tok[128] = "", key[128] = "", lic[32] = "",
         exp[64] = "", tier[32] = "";
    json_get_str(resp, "install_id", iid, sizeof(iid));
    json_get_str(resp, "token", tok, sizeof(tok));
    json_get_str(resp, "license_key", key, sizeof(key));
    json_get_str(resp, "license", lic, sizeof(lic));
    json_get_str(resp, "expires", exp, sizeof(exp));
    json_get_str(resp, "tier", tier, sizeof(tier));
    long seats = json_get_long(resp, "max_installs");
    cfg_set("install_id", iid);
    cfg_set("token", tok);
    if (*key) cfg_set("license_key", key);
    cfg_set("license_state", lic);
    cfg_set("license_expires", exp);
    cfg_set("license_tier", tier);
    char sb[16]; snprintf(sb, sizeof(sb), "%ld", seats);
    cfg_set("license_seats", sb);
    LOGI("cloud: registered as %s (plan %s, license %s)", iid, tier, lic);
    free(resp);
    return 0;
}

/* license active? mirrors the Windows/Linux client rules */
static int license_ok(void) {
    const char *st = cfg_get("license_state");
    if (strcmp(st, "active") == 0 || strcmp(st, "trial") == 0) return 1;
    if (strcmp(st, "past_due") == 0) {
        const char *exp = cfg_get("license_expires");
        if (!*exp) return 1;
        /* 72h grace after expiry */
        struct tm tm; memset(&tm, 0, sizeof(tm));
        char *rp = strptime(exp, "%Y-%m-%dT%H:%M:%S", &tm);
        if (rp) {
            time_t et = timegm(&tm);
            if (et > 0 && difftime(time(NULL), et) < GRACE_SECS) return 1;
        } else return 1;
    }
    return 0;
}

/* ---------------- heartbeat ---------------- */
static int g_scanMinutes = DEFAULT_SCAN_MIN;

static int cloud_heartbeat(void) {
    const char *iid = cfg_get("install_id");
    const char *tok = cfg_get("token");
    if (!*iid || !*tok) return cloud_register();
    char url[MAX_PATH + 32], srv[MAX_PATH];
    server_url(srv, sizeof(srv));
    snprintf(url, sizeof(url), "%s/api/heartbeat", srv);
    char host[256], esc_h[512];
    get_hostname(host, sizeof(host));
    json_escape(host, esc_h, sizeof(esc_h));
    const char *sv = cfg_get("sigs_version");
    char body[2048];
    snprintf(body, sizeof(body),
             "{\"install_id\":\"%s\",\"token\":\"%s\",\"hostname\":\"%s\",\"version\":\"%s\","
             "\"platform\":\"%s\",\"sigs_version\":%s,\"scanned\":%ld,\"detected\":%ld,"
             "\"last_quick\":\"%s\",\"last_full\":\"%s\"}",
             iid, tok, esc_h, VERSION, PLATFORM,
             *sv ? sv : "0", g_scanned, g_detected, g_lastQuick, g_lastFull);
    long code = 0;
    char *resp = http_post(url, body, &code);
    if (!resp) { LOGW("cloud: heartbeat failed (offline?)"); return -1; }
    if (!json_get_bool(resp, "ok")) {
        /* token may be stale (server DB reset) — re-register once */
        char err[128] = "";
        json_get_str(resp, "error", err, sizeof(err));
        LOGW("cloud: heartbeat rejected (%s), re-registering", err);
        free(resp);
        cfg_set("install_id", ""); cfg_set("token", "");
        return cloud_register();
    }
    char lic[32] = "", exp[64] = "", tier[32] = "";
    json_get_str(resp, "license", lic, sizeof(lic));
    json_get_str(resp, "expires", exp, sizeof(exp));
    json_get_str(resp, "tier", tier, sizeof(tier));
    long seats = json_get_long(resp, "max_installs");
    cfg_set("license_state", lic);
    cfg_set("license_expires", exp);
    if (*tier) cfg_set("license_tier", tier);
    char sb[16]; snprintf(sb, sizeof(sb), "%ld", seats);
    if (seats) cfg_set("license_seats", sb);
    /* sweep interval: server policy wins, then legacy hours, then default */
    long pm = json_get_long(resp, "policy_scan_minutes");
    if (pm > 0) g_scanMinutes = (int)pm;
    else {
        long ph = json_get_long(resp, "policy_scan_hours");
        if (ph > 0) g_scanMinutes = (int)(ph * 60);
    }
    if (g_scanMinutes < 1) g_scanMinutes = DEFAULT_SCAN_MIN;
    char sm[16]; snprintf(sm, sizeof(sm), "%d", g_scanMinutes);
    cfg_set("scan_minutes", sm);
    free(resp);
    return 0;
}

static void cloud_report_detection(const char *threat, const char *path) {
    const char *iid = cfg_get("install_id");
    const char *tok = cfg_get("token");
    if (!*iid || !*tok) return;
    char url[MAX_PATH + 32], srv[MAX_PATH];
    server_url(srv, sizeof(srv));
    snprintf(url, sizeof(url), "%s/api/detection", srv);
    char et[256], ep[MAX_PATH + 64];
    json_escape(threat, et, sizeof(et));
    json_escape(path, ep, sizeof(ep));
    char body[8192];
    snprintf(body, sizeof(body),
             "{\"install_id\":\"%s\",\"token\":\"%s\",\"threat\":\"%s\",\"path\":\"%s\"}",
             iid, tok, et, ep);
    long code = 0;
    char *resp = http_post(url, body, &code);
    if (resp) free(resp);
}

/* ---------------- updates ---------------- */
static int version_newer(const char *a, const char *b) {
    /* true if a > b (dotted numeric) */
    int x[4] = {0}, y[4] = {0};
    sscanf(a, "%d.%d.%d.%d", &x[0], &x[1], &x[2], &x[3]);
    sscanf(b, "%d.%d.%d.%d", &y[0], &y[1], &y[2], &y[3]);
    for (int i = 0; i < 4; i++)
        if (x[i] != y[i]) return x[i] > y[i];
    return 0;
}

/* Apple-only: relaunch ourselves through launchd after an engine update.
 * (The #else branch is the Linux re-exec path, kept so the file still
 * compiles as portable POSIX C for syntax checks.) */
static void restart_after_update(void) {
#ifdef __APPLE__
    LOGI("cloud: engine updated — cycling the launchd job");
    /* Paths contain no spaces here, but quote defensively anyway. */
    if (system("launchctl bootout system/com.aeantivirus.daemon >/dev/null 2>&1") != 0)
        LOGW("cloud: launchctl bootout reported an error (continuing)");
    if (system("launchctl bootstrap system '/Library/LaunchDaemons/com.aeantivirus.daemon.plist' >/dev/null 2>&1") != 0)
        LOGE("cloud: launchctl bootstrap failed — start the daemon manually");
    _exit(0);
#else
    char selfl[MAX_PATH];
    ssize_t sl = readlink("/proc/self/exe", selfl, sizeof(selfl) - 1);
    if (sl > 0) {
        selfl[sl] = 0;
        execl(selfl, selfl, g_foreground ? "--foreground" : "--daemon", NULL);
    }
    _exit(0);
#endif
}

/* download + verify + install a tarball update; returns 1 if updated */
static int cloud_check_updates(void) {
    char url[MAX_PATH + 64], srv[MAX_PATH];
    server_url(srv, sizeof(srv));
    snprintf(url, sizeof(url), "%s%s", srv, MANIFEST_PATH);
    char *resp = http_get(url);
    if (!resp) { LOGW("cloud: update check failed (offline?)"); return 0; }

    /* --- signature database --- */
    long sigsVer = json_get_long(resp, "sigs_version");
    long curSigs = atol(cfg_get("sigs_version"));
    char sigsUrl[512] = "", sigsSha[128] = "";
    json_get_str(resp, "sigs_url", sigsUrl, sizeof(sigsUrl));
    json_get_str(resp, "sigs_sha256", sigsSha, sizeof(sigsSha));
    if (sigsVer > curSigs && *sigsUrl && *sigsSha) {
        char full[1024];
        if (sigsUrl[0] == '/') snprintf(full, sizeof(full), "%s%s", srv, sigsUrl);
        else { strncpy(full, sigsUrl, sizeof(full)-1); full[sizeof(full)-1] = 0; }
        char tmp[MAX_PATH];
        snprintf(tmp, sizeof(tmp), "%s/signatures.db.new", g_appDir);
        LOGI("cloud: downloading signatures v%ld", sigsVer);
        if (http_download(full, tmp) == 0) {
            char hex[HASH_HEX+1];
            if (sha256_file(tmp, hex) == 0 && strcasecmp(hex, sigsSha) == 0) {
                if (rename(tmp, g_sigFile) == 0) {
                    sig_clear(); sig_add_builtin(); sig_load_file();
                    char sv[16]; snprintf(sv, sizeof(sv), "%ld", sigsVer);
                    cfg_set("sigs_version", sv);
                    LOGI("cloud: signatures updated to v%ld (%d loaded)", sigsVer, g_sigCount);
                } else LOGE("cloud: could not replace signatures.db");
            } else { LOGE("cloud: signature DB hash mismatch"); unlink(tmp); }
        }
    }

    /* --- engine package (tarball) --- */
    char ver[32] = "", pkgUrl[512] = "", pkgSha[128] = "";
    json_get_str(resp, "version", ver, sizeof(ver));
    json_get_str(resp, "exe_url", pkgUrl, sizeof(pkgUrl));
    json_get_str(resp, "exe_sha256", pkgSha, sizeof(pkgSha));
    free(resp);
    if (*ver && *pkgUrl && *pkgSha && version_newer(ver, VERSION)) {
        char full[1024];
        if (pkgUrl[0] == '/') snprintf(full, sizeof(full), "%s%s", srv, pkgUrl);
        else { strncpy(full, pkgUrl, sizeof(full)-1); full[sizeof(full)-1] = 0; }
        char tmp[MAX_PATH];
        snprintf(tmp, sizeof(tmp), "/tmp/aea-update-%d.tar.gz", (int)getpid());
        LOGI("cloud: downloading engine update v%s", ver);
        if (http_download(full, tmp) == 0) {
            char hex[HASH_HEX+1];
            if (sha256_file(tmp, hex) == 0 && strcasecmp(hex, pkgSha) == 0) {
                char xdir[MAX_PATH];
                snprintf(xdir, sizeof(xdir), "/tmp/aea-update-%d", (int)getpid());
                mkdir_p(xdir, 0700);
                char cmd[MAX_PATH * 3];
                snprintf(cmd, sizeof(cmd), "tar -xzf '%s' -C '%s'", tmp, xdir);
                if (system(cmd) == 0) {
                    /* tarball layout: aeantivirusd binary at top level */
                    char src[MAX_PATH], dst[MAX_PATH];
                    snprintf(src, sizeof(src), "%s/aeantivirusd", xdir);
                    if (access(src, X_OK) != 0) {
                        /* try nested dir */
                        snprintf(cmd, sizeof(cmd),
                                 "find '%s' -name aeantivirusd -type f | head -1", xdir);
                        FILE *pp = popen(cmd, "r");
                        if (pp) {
                            if (fgets(src, sizeof(src), pp))
                                src[strcspn(src, "\r\n")] = 0;
                            pclose(pp);
                        }
                    }
                    snprintf(dst, sizeof(dst), "%s", INSTALL_BIN);
                    if (access(src, X_OK) == 0) {
                        char bak[MAX_PATH + 8];
                        snprintf(bak, sizeof(bak), "%s.bak", dst);
                        rename(dst, bak);
                        if (rename(src, dst) == 0) {
                            chmod(dst, 0755);
                            LOGI("cloud: engine updated to v%s — restarting", ver);
                            unlink(tmp);
                            snprintf(cmd, sizeof(cmd), "rm -rf '%s'", xdir);
                            if (system(cmd) != 0) LOGW("cloud: cleanup of %s failed", xdir);
                            restart_after_update();
                            return 1; /* not reached */
                        }
                        rename(bak, dst);
                    }
                    LOGE("cloud: update tarball had no usable binary");
                } else LOGE("cloud: could not extract update tarball");
                snprintf(cmd, sizeof(cmd), "rm -rf '%s'", xdir);
                if (system(cmd) != 0) LOGW("cloud: cleanup of %s failed", xdir);
            } else LOGE("cloud: engine package hash mismatch");
            unlink(tmp);
        }
    }
    return 0;
}

/* ------------------------------------------------------------------ */
/* Scans                                                               */
/* ------------------------------------------------------------------ */
/* Quick (polling) sweep: temp dirs, /Users/Shared, and every local
 * user's Downloads + Desktop. This is the v1 protection loop — it runs
 * every scan_minutes (default 15), not on file-close. */
static void do_quick_scan(void) {
    LOGI("quick scan started");
    char iso[64]; now_iso(iso, sizeof(iso));
    int files = 0, hits = 0;
    const char *roots[] = { "/tmp", "/var/tmp", "/Users/Shared", NULL };
    for (int i = 0; roots[i]; i++) scan_tree(roots[i], &files, &hits);
    DIR *d = opendir("/Users");
    if (d) {
        struct dirent *e; char sub[MAX_PATH];
        while ((e = readdir(d))) {
            if (e->d_name[0] == '.') continue;
            if (strcmp(e->d_name, "Shared") == 0) continue;
            snprintf(sub, sizeof(sub), "/Users/%s", e->d_name);
            struct stat st;
            if (lstat(sub, &st) != 0 || !S_ISDIR(st.st_mode)) continue;
            char t2[MAX_PATH];
            snprintf(t2, sizeof(t2), "%s/Downloads", sub); scan_tree(t2, &files, &hits);
            snprintf(t2, sizeof(t2), "%s/Desktop", sub); scan_tree(t2, &files, &hits);
        }
        closedir(d);
    }
    strncpy(g_lastQuick, iso, sizeof(g_lastQuick)-1);
    g_lastQuick[sizeof(g_lastQuick)-1] = 0;
    stats_save();
    LOGI("quick scan done: %d files, %d threats", files, hits);
}
static void do_full_scan(void) {
    LOGI("full scan started");
    char iso[64]; now_iso(iso, sizeof(iso));
    int files = 0, hits = 0;
    /* /System, /private, /dev, /Network, /Volumes are skipped by
     * should_skip_path() inside scan_tree. */
    const char *roots[] = { "/Users", "/Applications", "/tmp", "/var/tmp",
                            "/opt", "/usr/local", NULL };
    for (int i = 0; roots[i]; i++) scan_tree(roots[i], &files, &hits);
    strncpy(g_lastFull, iso, sizeof(g_lastFull)-1);
    g_lastFull[sizeof(g_lastFull)-1] = 0;
    stats_save();
    LOGI("full scan done: %d files, %d threats", files, hits);
}

/* ------------------------------------------------------------------ */
/* Daemon main loop                                                    */
/* ------------------------------------------------------------------ */
static volatile int g_running = 1;
static void on_signal(int sig) { (void)sig; g_running = 0; }

static int run_daemon(void) {
    signal(SIGTERM, on_signal);
    signal(SIGINT, on_signal);
    signal(SIGHUP, SIG_IGN);
    signal(SIGPIPE, SIG_IGN);

    cfg_load();
    stats_load();
    sig_add_builtin();
    sig_write_defaults();
    sig_load_file();
    LOGI("AEAntivirus %s starting (%d signatures)", VERSION, g_sigCount);
    curl_global_init(CURL_GLOBAL_DEFAULT);

    if (!*cfg_get("install_id")) {
        LOGI("no install id — registering");
        cloud_register(); /* best effort; retries on heartbeat */
    }
    const char *sm = cfg_get("scan_minutes");
    if (*sm && atoi(sm) > 0) g_scanMinutes = atoi(sm);

    /* refresh license state + policy before the first sweep, so an
     * expired/invalid license never gets protection */
    cloud_heartbeat();

    if (license_ok())
        LOGI("protection active (polling sweep every %d min)", g_scanMinutes);
    else
        LOGW("protection paused (license %s)", cfg_get("license_state"));

    time_t lastHb = time(NULL), lastScan = time(NULL) - (time_t)g_scanMinutes * 60,
           lastUpd = time(NULL), lastFull = time(NULL);
    while (g_running) {
        /* 1-second tick; cheap enough and keeps shutdown responsive */
        struct timespec ts = { 1, 0 };
        nanosleep(&ts, NULL);

        time_t now = time(NULL);
        if (now - lastHb >= HEARTBEAT_SECS) {
            lastHb = now;
            cloud_heartbeat();
        }
        if (now - lastScan >= (time_t)g_scanMinutes * 60) {
            lastScan = now;
            if (license_ok()) do_quick_scan();
            else LOGW("sweep skipped — license %s", cfg_get("license_state"));
        }
        if (now - lastFull >= FULLSCAN_SECS) {
            lastFull = now;
            if (license_ok()) do_full_scan();
        }
        if (now - lastUpd >= UPDATE_SECS) {
            lastUpd = now;
            cloud_check_updates(); /* restarts itself on engine update */
        }
    }
    LOGI("AEAntivirus stopping");
    stats_save();
    curl_global_cleanup();
    return 0;
}

/* ------------------------------------------------------------------ */
/* CLI                                                                 */
/* ------------------------------------------------------------------ */
static void print_status(void) {
    cfg_load(); stats_load();
    /* snapshot: cfg_get returns a shared static buffer, so copy each value */
    char st[64], key[128], srv[512], iid[64], tier[64], seats[32], exp[64], sigsv[32], smin[16];
    strncpy(st, cfg_get("license_state"), sizeof(st) - 1); st[sizeof(st)-1] = 0;
    strncpy(key, cfg_get("license_key"), sizeof(key) - 1); key[sizeof(key)-1] = 0;
    strncpy(srv, cfg_get("server_url"), sizeof(srv) - 1); srv[sizeof(srv)-1] = 0;
    strncpy(iid, cfg_get("install_id"), sizeof(iid) - 1); iid[sizeof(iid)-1] = 0;
    strncpy(tier, cfg_get("license_tier"), sizeof(tier) - 1); tier[sizeof(tier)-1] = 0;
    strncpy(seats, cfg_get("license_seats"), sizeof(seats) - 1); seats[sizeof(seats)-1] = 0;
    strncpy(exp, cfg_get("license_expires"), sizeof(exp) - 1); exp[sizeof(exp)-1] = 0;
    strncpy(sigsv, cfg_get("sigs_version"), sizeof(sigsv) - 1); sigsv[sizeof(sigsv)-1] = 0;
    strncpy(smin, cfg_get("scan_minutes"), sizeof(smin) - 1); smin[sizeof(smin)-1] = 0;
    printf("AEAntivirus %s (macos)\n", VERSION);
    printf("Server:    %s\n", *srv ? srv : "(not set)");
    printf("Install:   %s\n", *iid ? iid : "(not registered)");
    printf("License:   %s  key=%s\n", *st ? st : "(not registered)", *key ? key : "(none)");
    printf("Plan:      %s (%s Macs)\n", *tier ? tier : "?", *seats ? seats : "?");
    printf("Expires:   %s\n", *exp ? exp : "never");
    printf("Signatures: v%s (%d loaded)\n", *sigsv ? sigsv : "0", g_sigCount);
    printf("Scanned:   %ld files   Detected: %ld threats\n", g_scanned, g_detected);
    printf("Last sweep: %s   Last full: %s\n",
           *g_lastQuick ? g_lastQuick : "never", *g_lastFull ? g_lastFull : "never");
    printf("Sweep interval: %s minutes\n", *smin ? smin : "15");
    printf("Protection: %s\n", license_ok() ? "ACTIVE (polling sweeps)" : "PAUSED (license)");
}

static void quarantine_list(void) {
    DIR *d = opendir(g_quarDir);
    if (!d) { printf("quarantine is empty\n"); return; }
    struct dirent *e;
    printf("%-6s %-20s %s\n", "ID", "DATE", "THREAT  <- ORIGINAL PATH");
    while ((e = readdir(d))) {
        size_t l = strlen(e->d_name);
        if (l < 6 || strcmp(e->d_name + l - 5, ".meta") != 0) continue;
        char mp[MAX_PATH], orig[MAX_PATH] = "?", date[64] = "?", threat[128] = "?";
        snprintf(mp, sizeof(mp), "%s/%s", g_quarDir, e->d_name);
        FILE *f = fopen(mp, "r");
        if (f) {
            char line[512];
            while (fgets(line, sizeof(line), f)) {
                if (strncmp(line, "original_path=", 14) == 0)
                    { strncpy(orig, line + 14, sizeof(orig)-1); orig[sizeof(orig)-1] = 0; orig[strcspn(orig, "\r\n")] = 0; }
                else if (strncmp(line, "date=", 5) == 0)
                    { strncpy(date, line + 5, sizeof(date)-1); date[sizeof(date)-1] = 0; date[strcspn(date, "\r\n")] = 0; }
                else if (strncmp(line, "threat=", 7) == 0)
                    { strncpy(threat, line + 7, sizeof(threat)-1); threat[sizeof(threat)-1] = 0; threat[strcspn(threat, "\r\n")] = 0; }
            }
            fclose(f);
        }
        char id[32];
        strncpy(id, e->d_name, sizeof(id) - 1);
        id[sizeof(id) - 1] = 0;
        char *dot = strrchr(id, '.');
        if (dot) *dot = 0;   /* strip ".meta" */
        printf("%-6s %-20s %s <- %s\n", id, date, threat, orig);
    }
    closedir(d);
}
static void quarantine_restore(const char *id) {
    char src[MAX_PATH], meta[MAX_PATH], orig[MAX_PATH] = "";
    snprintf(src, sizeof(src), "%s/%s", g_quarDir, id);
    snprintf(meta, sizeof(meta), "%s/%s.meta", g_quarDir, id);
    FILE *f = fopen(meta, "r");
    if (f) {
        char line[512];
        while (fgets(line, sizeof(line), f))
            if (strncmp(line, "original_path=", 14) == 0)
                { strncpy(orig, line + 14, sizeof(orig)-1); orig[sizeof(orig)-1] = 0; orig[strcspn(orig, "\r\n")] = 0; }
        fclose(f);
    }
    if (!*orig) { printf("no metadata for id %s\n", id); return; }
    char dir[MAX_PATH]; strncpy(dir, orig, sizeof(dir)-1); dir[sizeof(dir)-1] = 0;
    char *sl = strrchr(dir, '/');
    if (sl) { *sl = 0; }
    struct stat st;
    if (stat(dir, &st) != 0) {
        printf("original directory %s no longer exists — cannot restore\n", dir);
        return;
    }
    if (rename(src, orig) == 0) { unlink(meta); printf("restored to %s\n", orig); }
    else printf("restore failed: %s\n", strerror(errno));
}
static void quarantine_delete(const char *id) {
    char src[MAX_PATH], meta[MAX_PATH];
    snprintf(src, sizeof(src), "%s/%s", g_quarDir, id);
    snprintf(meta, sizeof(meta), "%s/%s.meta", g_quarDir, id);
    struct stat st;
    if (stat(src, &st) != 0) { printf("no quarantine entry %s\n", id); return; }
    unlink(src); unlink(meta);
    printf("deleted quarantine entry %s\n", id);
}

static void usage(const char *p0) {
    printf("AEAntivirus %s for macOS\n", VERSION);
    printf("usage: %s [command]\n", p0);
    printf("  (no command)             run the protection daemon (what launchd invokes)\n");
    printf("  --daemon                 run the protection daemon\n");
    printf("  --foreground             run the daemon in the foreground (debugging)\n");
    printf("  --version                print version\n");
    printf("  --status                 show protection status\n");
    printf("  --scan-quick             sweep temp + downloads + desktop now\n");
    printf("  --scan-full              scan user dirs + applications now\n");
    printf("  --scan <path> [path...]  scan files or directories now\n");
    printf("  --register               register / re-register with the server\n");
    printf("  --heartbeat              send one heartbeat now\n");
    printf("  --check-update           check for engine + signature updates\n");
    printf("  --set-server <url>       set the server URL\n");
    printf("  --set-key <key>          set the license key (re-registers)\n");
    printf("  --quarantine-list        list quarantined files\n");
    printf("  --quarantine-restore <id>\n");
    printf("  --quarantine-delete <id>\n");
}

int main(int argc, char **argv) {
    init_paths();
    mkdirs();
    /* Bare invocation (how launchd starts us) runs the daemon. Any other
     * recognized command runs in the foreground with stderr logging. */
    int is_daemon_cmd = argc < 2 ||
        strcmp(argv[1], "--daemon") == 0 ||
        strcmp(argv[1], "--foreground") == 0;
    if (!is_daemon_cmd) g_foreground = 1;
    log_init();
    cfg_load();
    stats_load();
    sig_add_builtin();
    sig_load_file();

    if (argc < 2 || strcmp(argv[1], "--daemon") == 0) return run_daemon();
    if (strcmp(argv[1], "--foreground") == 0) return run_daemon();
    if (strcmp(argv[1], "--version") == 0) { printf("AEAntivirus %s (macos)\n", VERSION); return 0; }
    if (strcmp(argv[1], "--status") == 0) { print_status(); return 0; }
    if (strcmp(argv[1], "--scan-quick") == 0) { do_quick_scan(); return 0; }
    if (strcmp(argv[1], "--scan-full") == 0) { do_full_scan(); return 0; }
    if (strcmp(argv[1], "--scan") == 0 && argc > 2) {
        int files = 0, hits = 0;
        for (int i = 2; i < argc; i++) {
            struct stat st;
            if (lstat(argv[i], &st) == 0 && S_ISDIR(st.st_mode)) {
                scan_tree(argv[i], &files, &hits);
            } else {
                files++; g_scanned++;
                const char *t = scan_file(argv[i]);
                if (t) { hits++; handle_detection(argv[i], t); }
            }
        }
        printf("scanned %d, threats %d\n", files, hits);
        return 0;
    }
    if (strcmp(argv[1], "--register") == 0) {
        curl_global_init(CURL_GLOBAL_DEFAULT);
        int r = cloud_register();
        curl_global_cleanup();
        return r == 0 ? 0 : 1;
    }
    if (strcmp(argv[1], "--heartbeat") == 0) {
        curl_global_init(CURL_GLOBAL_DEFAULT);
        int r = cloud_heartbeat();
        curl_global_cleanup();
        return r == 0 ? 0 : 1;
    }
    if (strcmp(argv[1], "--check-update") == 0) {
        curl_global_init(CURL_GLOBAL_DEFAULT);
        int r = cloud_check_updates();
        curl_global_cleanup();
        printf(r ? "engine updated\n" : "no engine update\n");
        return 0;
    }
    if (strcmp(argv[1], "--set-server") == 0 && argc > 2) {
        cfg_set("server_url", argv[2]);
        printf("server URL set to %s\n", argv[2]);
        return 0;
    }
    if (strcmp(argv[1], "--set-key") == 0 && argc > 2) {
        cfg_set("license_key", argv[2]);
        /* force re-registration with the new key */
        cfg_set("install_id", "");
        cfg_set("token", "");
        printf("license key updated — will re-register on next start\n");
        return 0;
    }
    if (strcmp(argv[1], "--quarantine-list") == 0) { quarantine_list(); return 0; }
    if (strcmp(argv[1], "--quarantine-restore") == 0 && argc > 2) { quarantine_restore(argv[2]); return 0; }
    if (strcmp(argv[1], "--quarantine-delete") == 0 && argc > 2) { quarantine_delete(argv[2]); return 0; }
    usage(argv[0]);
    return 1;
}
