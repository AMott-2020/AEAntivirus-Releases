#!/bin/sh
# AEAntivirus macOS uninstaller.
#
#   sudo ./uninstall.sh           # unloads daemon, removes program files,
#                                 # keeps the quarantine directory
#   sudo ./uninstall.sh --purge   # also deletes quarantined files
set -u

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: run as root: sudo ./uninstall.sh" >&2
    exit 1
fi

PURGE=0
[ "${1:-}" = "--purge" ] && PURGE=1

APP_SUPPORT="/Library/Application Support/AEAntivirus"

echo "Unloading AEAntivirus daemon..."
launchctl bootout system/com.aeantivirus.daemon >/dev/null 2>&1 || true
rm -f /Library/LaunchDaemons/com.aeantivirus.daemon.plist
rm -rf /usr/local/libexec/aeantivirus

if [ "$PURGE" -eq 1 ]; then
    rm -rf "$APP_SUPPORT"
    echo "Uninstalled. Quarantine purged."
else
    if [ -d "$APP_SUPPORT/quarantine" ]; then
        # Keep quarantined files: move them aside, wipe the rest, move back.
        KEEP="$(mktemp -d /tmp/aeantivirus-quarantine-keep.XXXXXX)"
        cp -R "$APP_SUPPORT/quarantine" "$KEEP/" 2>/dev/null || true
        rm -rf "$APP_SUPPORT"
        mkdir -p "$APP_SUPPORT"
        mv "$KEEP/quarantine" "$APP_SUPPORT/" 2>/dev/null || true
        rmdir "$KEEP" 2>/dev/null || true
        echo "Uninstalled. Quarantine kept at: $APP_SUPPORT/quarantine"
        echo "(re-run with --purge to delete quarantined files)"
    else
        rm -rf "$APP_SUPPORT"
        echo "Uninstalled."
    fi
fi
