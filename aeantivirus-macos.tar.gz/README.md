# AEAntivirus 1.15.0 for macOS — `aeantivirusd`

> **⚠️ UNTESTED ON A REAL MAC — written and logic-tested on Linux only.**
> The daemon below was written on a Linux machine. Its scan engine,
> quarantine, config, CLI, and license logic were compiled and exercised
> on Linux against stubbed network calls (see "What was actually verified").
> It has **never been compiled or executed on macOS**. Do not ship to
> customers without building, installing, and exercising it on real macOS
> hardware (see "What still needs verification" below).

## What v1 does

`aeantivirusd` is the macOS counterpart of the Linux AEAntivirus client:
a root system daemon managed by launchd that protects the Mac on a
**polling** model — no desktop GUI.

- **Periodic sweeps** — every 15 minutes (configurable via `scan_minutes`;
  server policy `policy_scan_minutes` overrides) it scans `/tmp`,
  `/var/tmp`, `/Users/Shared`, and every local user's `Downloads` and
  `Desktop` folders.
- **On-demand scans** — `aeantivirusd --scan <path> [path...]`,
  `--scan-quick`, `--scan-full` (`/Users`, `/Applications`, `/tmp`,
  `/var/tmp`, `/opt`, `/usr/local`; system locations like `/System`,
  `/private`, `/dev`, `/Network`, `/Volumes` are skipped).
- **Scan engine** — SHA-256 of each file vs `signatures.db`
  (`<sha256-hex> <threat name>` per line, `#` comments; includes the EICAR
  test file), plus heuristics: double extensions (`invoice.pdf.sh`),
  suspicious Mach-O binaries ( Mach-O magic + tokens like `ptrace`,
  `task_for_pid`, `AuthorizationExecuteWithPrivileges`, LaunchDaemon
  persistence paths), and suspicious shell scripts (shebang + downloader /
  `eval` / `base64` / `osascript` patterns). Heuristic hits are reported as
  `AI.Heuristic.Suspicious` — suspicious, not confirmed malware.
- **Quarantine** — threats are moved to the quarantine dir (mode 0600)
  with a `.meta` sidecar (original path, date, threat name); list, restore,
  or delete from the CLI.
- **Cloud sync (libcurl, HTTPS)** — same protocol as the Linux client:
  - `POST /api/register` `{license_key?, hostname, version:"1.15.0", platform:"macos"}`
    → `{ok, install_id, token, license_key, license, expires, tier, max_installs}` (empty key = trial)
  - `POST /api/heartbeat` `{install_id, token, hostname, version, sigs_version, scanned, detected, last_quick, last_full, platform:"macos"}`
    → `{ok, license, expires, tier, max_installs, policy_scan_minutes}`
  - `POST /api/detection` `{install_id, token, threat, path}` → `{ok}`
  - `GET /updates/manifest-macos.json`
    → `{version, exe_url, exe_sha256, sigs_version, sigs_url, sigs_sha256}`
- **Self-update** — `--check-update` downloads a newer engine tarball,
  verifies SHA-256, extracts, replaces the binary, and cycles the launchd
  job (`launchctl bootout` + `bootstrap`). Signature updates are verified
  the same way and applied automatically (check every 6 hours).
- **License enforcement** — protection is active for `active`/`trial`, or
  `past_due` inside a 72-hour grace window after expiry; otherwise sweeps
  are skipped with a (throttled) syslog warning. `--status` shows
  `Plan: <tier> (<seats> Macs)`.
- **Logging** — syslog, facility `LOG_DAEMON`, ident `aeantivirusd`
  (stderr when run as a CLI command).

## What v1 does NOT do

- **No realtime on-access scanning.** A file is only checked when a sweep
  or manual scan reaches it — a threat can sit undetected for up to one
  sweep interval (15 minutes by default). True on-access protection on
  macOS requires an EndpointSecurity system extension plus Apple Developer
  approval and explicit user consent in System Settings; that is a future
  release, not v1.
- **No GUI / menu-bar app.** All management is via the CLI and the server
  fleet dashboard.
- **Not notarized.** An unsigned binary downloaded from the internet will
  be blocked by Gatekeeper (see Production notes).

## Layout

```
macos/
├── README.md                        ← this file
├── build.sh                         build on a Mac: ./build.sh
├── com.aeantivirus.daemon.plist     → /Library/LaunchDaemons/
├── signatures.db                    → /Library/Application Support/AEAntivirus/
├── install.sh                       run as root: sudo ./install.sh
├── uninstall.sh                     run as root: sudo ./uninstall.sh [--purge]
└── daemon/
    ├── aeantivirusd.c               the daemon (~1330 lines, C11, portable POSIX)
    └── sha256.c / sha256.h          public-domain SHA-256 + sha256_file() helper
```

Installed locations:

| Path | Purpose |
|---|---|
| `/usr/local/libexec/aeantivirus/aeantivirusd` | daemon binary |
| `/Library/LaunchDaemons/com.aeantivirus.daemon.plist` | launchd job (root:wheel, 644) |
| `/Library/Application Support/AEAntivirus/config` | `key=value` config (0600) |
| `/Library/Application Support/AEAntivirus/signatures.db` | signature database |
| `/Library/Application Support/AEAntivirus/quarantine/` | quarantined files + `.meta` records |
| `/Library/Application Support/AEAntivirus/stats` | scan counters |
| `/Library/Application Support/AEAntivirus/daemon.log` | stdout/stderr capture |

## Building (on a Mac)

Requires Xcode command line tools (`xcode-select --install`). No other
dependencies — clang plus the libcurl that ships with macOS.

```sh
cd macos
./build.sh        # produces daemon/aeantivirusd
```

For testing on Linux (syntax + offline logic only, network calls stubbed
out — never a real macOS binary):

```sh
# not part of the release process; used during development only
```

## Installing

```sh
cd macos
sudo ./install.sh
```

The installer prompts for the server URL (default `https://aeantivirus.com`)
and a license key (empty = 7-day trial), or pass them non-interactively:

```sh
sudo AEA_SERVER_URL=https://av.example.com AEA_LICENSE_KEY=AEA-XXXX ./install.sh
```

It copies the binary, installs the launchd plist, writes the default config
+ signatures, registers with the server via the daemon's own `--register`,
and bootstraps the daemon:

```sh
sudo launchctl bootstrap system /Library/LaunchDaemons/com.aeantivirus.daemon.plist
```

Check it with:

```sh
sudo /usr/local/libexec/aeantivirus/aeantivirusd --status
```

## Uninstalling

```sh
sudo ./uninstall.sh           # unloads daemon, removes program files, keeps quarantine
sudo ./uninstall.sh --purge   # also deletes quarantined files
```

## CLI reference

```
aeantivirusd                      run the protection daemon (what launchd invokes)
aeantivirusd --daemon             run the protection daemon
aeantivirusd --foreground         run the daemon in the foreground (debugging)
aeantivirusd --version
aeantivirusd --status             license, plan, stats, sweep interval
aeantivirusd --scan-quick         sweep temp + downloads + desktop now
aeantivirusd --scan-full          scan user dirs + applications now
aeantivirusd --scan <path> [path...]  scan files or directories now
aeantivirusd --register           register / re-register with the server
aeantivirusd --heartbeat          send one heartbeat now
aeantivirusd --check-update       check for engine + signature updates
aeantivirusd --set-server <url>   set the server URL
aeantivirusd --set-key <key>      set the license key (re-registers)
aeantivirusd --quarantine-list
aeantivirusd --quarantine-restore <id>
aeantivirusd --quarantine-delete <id>
```

Config lives in `/Library/Application Support/AEAntivirus/config`
(`key=value`, mode 0600). For testing, set `AEA_BASE=/tmp/xyz` to redirect
all paths under a sandbox directory. Tunables: `scan_minutes` (default 15),
`server_url`, `license_key`, `sigs_version`.

## Production notes (read before shipping)

- **Gatekeeper / notarization.** An unsigned binary downloaded from the
  internet will be blocked by Gatekeeper. Production releases need
  Developer ID signing (`codesign --sign "Developer ID Application: …"`)
  **and** Apple notarization (`xcrun notarytool`), with the ticket stapled.
  Signing changes the binary hash — the server's `manifest-macos.json`
  `exe_sha256` must match the signed artifact.
- **Full Disk Access.** The daemon runs as root via launchd, which covers
  ordinary file access, but macOS Transparency Consent and Control (TCC)
  protections around Mail, Safari, Photos data, etc. may still deny reads.
  A daemon has no GUI to prompt with — plan an MDM profile or documented
  manual Full Disk Access approval for managed fleets.
- **No on-access protection (v1).** Say so in customer-facing copy. The
  sweep interval is the detection-latency bound.
- **Engine updates replace a running binary.** The launchd cycle
  (`bootout` + `bootstrap`) is best-effort; if `bootstrap` fails the Mac
  is left without the daemon until it is started manually — monitor the
  fleet's `last_seen` after pushing an engine update.

## What was actually verified (on Linux, not macOS)

- `gcc -fsyntax-only -Wall -Wextra -std=c11` on `aeantivirusd.c` +
  `sha256.c`: clean, zero warnings. All Apple-specific code is inside
  `#ifdef __APPLE__` (launchd restart path); the rest is portable POSIX C.
- Full compile + link against a stub libcurl and functional tests of the
  offline logic with `AEA_BASE` sandboxing:
  - `--scan` on a directory: EICAR file → `EICAR-Test-File` signature hit;
    `invoice.pdf.sh` → `AI.Heuristic.Suspicious` (double extension);
    `evil.sh` (shebang + curl|sh + eval + base64) → `AI.Heuristic.Suspicious`;
    crafted fat-Mach-O with `ptrace`/`task_for_pid`/LaunchDaemon strings →
    `AI.Heuristic.Suspicious`; clean text file untouched.
  - Quarantine round-trip: all 4 threats moved with `.meta` sidecars,
    `--quarantine-list` shows id/date/threat/original path, `--restore`
    returned the file, `--delete` removed the entry.
  - `--status`, `--set-server`, `--version` all behave; unlicensed state
    correctly reports `PAUSED (license)`.
- `sh -n` on `build.sh`, `install.sh`, `uninstall.sh`; plist parses as XML.
- `sha256_file()` matches the EICAR vector pinned in `signatures.db`
  (`275a021b…51fd0f`).

## What still needs verification (on a real Mac)

1. `./build.sh` compiles and links against the real macOS libcurl.
2. `sudo ./install.sh` — plist loads, daemon starts, no TCC/permission surprises.
3. EICAR file in `~/Downloads` is caught on the next sweep, quarantined, reported.
4. Double-extension, suspicious-script, and Mach-O heuristic detections on real files.
5. `--quarantine-list` / `--quarantine-restore` / `--quarantine-delete` round-trip.
6. `--register` (trial + paid key), `--heartbeat`, license expiry → paused sweeps.
7. `--check-update` engine replacement + launchd bootout/bootstrap cycle.
8. Signature auto-update via the 6-hour check.
9. Uninstall with and without `--purge`.
10. Behavior on Apple Silicon vs Intel (universal binary via `lipo` if both are targeted).
11. Sweep performance on a real user home directory (15-minute default vs. scan time).
