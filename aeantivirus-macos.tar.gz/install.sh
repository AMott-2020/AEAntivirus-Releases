#!/bin/sh
# AEAntivirus 1.15.0 macOS installer.
#
# Must be run as root:  sudo ./install.sh
#
# Non-interactive (fleets):
#   sudo AEA_SERVER_URL=https://av.example.com AEA_LICENSE_KEY=AEA-XXXX ./install.sh
#
# Installs:
#   /usr/local/libexec/aeantivirus/aeantivirusd      (the daemon binary)
#   /Library/LaunchDaemons/com.aeantivirus.daemon.plist
#   /Library/Application Support/AEAntivirus/       (config, signatures, quarantine)
#
# Prompts for the server URL (default https://aeantivirus.com) and an
# optional license key. An empty license key starts the 7-day trial via
# POST /api/register. If registration fails here, the daemon retries
# on every start until it succeeds.
set -u

if [ "$(id -u)" -ne 0 ]; then
    echo "ERROR: run as root: sudo ./install.sh" >&2
    exit 1
fi

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
BIN="$SRC_DIR/daemon/aeantivirusd"
if [ ! -x "$BIN" ]; then
    echo "ERROR: $BIN not found. Build first on a Mac:  ./build.sh" >&2
    exit 1
fi

APP_SUPPORT="/Library/Application Support/AEAntivirus"
BIN_DIR="/usr/local/libexec/aeantivirus"
PLIST_DST="/Library/LaunchDaemons/com.aeantivirus.daemon.plist"
DEFAULT_URL="https://aeantivirus.com"

SERVER_URL="${AEA_SERVER_URL:-}"
LICENSE_KEY="${AEA_LICENSE_KEY:-}"

if [ -z "$SERVER_URL" ]; then
    if [ -t 0 ]; then
        printf 'AEAntivirus server URL [%s]: ' "$DEFAULT_URL"
        read -r SERVER_URL
    fi
    [ -z "$SERVER_URL" ] && SERVER_URL="$DEFAULT_URL"
fi
# Strip a trailing slash so URL building stays predictable.
SERVER_URL="$(printf '%s' "$SERVER_URL" | sed 's:/*$::')"

if [ -z "${AEA_LICENSE_KEY:-}" ]; then
    if [ -t 0 ]; then
        printf 'License key (empty = start 7-day trial): '
        read -r LICENSE_KEY
    else
        LICENSE_KEY=""
    fi
fi

echo "Installing AEAntivirus 1.15.0..."
mkdir -p "$BIN_DIR" "$APP_SUPPORT/quarantine"
cp -f "$BIN" "$BIN_DIR/aeantivirusd"
chmod 755 "$BIN_DIR/aeantivirusd"
cp -f "$SRC_DIR/com.aeantivirus.daemon.plist" "$PLIST_DST"
chown root:wheel "$PLIST_DST"
chmod 644 "$PLIST_DST"
cp -f "$SRC_DIR/signatures.db" "$APP_SUPPORT/signatures.db"
chmod 644 "$APP_SUPPORT/signatures.db"
touch "$APP_SUPPORT/daemon.log"
chmod 640 "$APP_SUPPORT/daemon.log"

# Write the base config with printf (safe for any characters in the key/URL).
{
    printf 'server_url=%s\n' "$SERVER_URL"
    printf 'license_key=%s\n' "$LICENSE_KEY"
    printf 'install_id=\n'
    printf 'token=\n'
    printf 'license_state=\n'
    printf 'license_expires=\n'
    printf 'license_tier=\n'
    printf 'license_seats=\n'
    printf 'sigs_version=1\n'
    printf 'scan_minutes=15\n'
} > "$APP_SUPPORT/config"
chmod 600 "$APP_SUPPORT/config"

# Register with the server now so the install_id/token exist immediately.
# Uses the daemon's own --register (it rewrites the config safely); on
# failure the daemon retries registration on every start.
if "$BIN_DIR/aeantivirusd" --register; then
    echo "Registered with $SERVER_URL."
else
    echo "WARNING: server registration failed. The daemon will retry on start." >&2
fi
chmod 600 "$APP_SUPPORT/config"

# (Re)load the daemon.
launchctl bootout system/com.aeantivirus.daemon >/dev/null 2>&1 || true
if launchctl bootstrap system "$PLIST_DST" 2>&1; then
    echo "AEAntivirus daemon is running."
else
    echo "ERROR: launchctl bootstrap failed. Try manually:" >&2
    echo "  sudo launchctl bootstrap system $PLIST_DST" >&2
    exit 1
fi

echo "Done. Check status with:  sudo /usr/local/libexec/aeantivirus/aeantivirusd --status"
