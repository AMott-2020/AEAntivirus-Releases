#!/bin/bash
# AEAntivirus for Linux — installer. Run as root:  sudo ./install.sh
# Installs the aeantivirusd protection daemon as a systemd service.
#
# Every install requires an AEAntivirus account — even a free one. The
# installer signs you in (or creates a free account for you) and activates
# the install with that session. There is no anonymous install path: without
# a valid account sign-in the installer aborts before anything is enabled.
#
# Non-interactive (fleet) usage:
#   sudo AEA_SERVER_URL=https://av.example.com \
#        AEA_ACCOUNT_NEW=new|existing \
#        AEA_ACCOUNT_EMAIL=you@example.com \
#        AEA_ACCOUNT_PASSWORD='s3cret-passphrase' \
#        AEA_LICENSE_KEY=AEA-XXXX ./install.sh
# (AEA_LICENSE_KEY is optional — blank starts a free 7-day trial on the account.)
set -e

SRC_DIR="$(cd "$(dirname "$0")" && pwd)"
BIN=/usr/local/bin/aeantivirusd
UNIT=/etc/systemd/system/aeantivirus.service

# ---------------------------------------------------------------------------
# 1.97.0: AE-branded terminal styling (matches the Windows UI: dark theme,
# cyan accents). Graceful fallback: no colors when not on a TTY, when
# NO_COLOR is set, or when the terminal can't do color.
# ---------------------------------------------------------------------------
if [ -t 1 ] && [ -z "${NO_COLOR:-}" ] && command -v tput >/dev/null 2>&1 \
   && [ "$(tput colors 2>/dev/null || echo 0)" -ge 8 ]; then
  AE_CYAN="$(tput setaf 6 || true)$(tput bold || true)"
  AE_DIM="$(tput setaf 8 || true)"
  AE_GREEN="$(tput setaf 2 || true)$(tput bold || true)"
  AE_RED="$(tput setaf 1 || true)$(tput bold || true)"
  AE_RESET="$(tput sgr0 || true)"
else
  AE_CYAN= AE_DIM= AE_GREEN= AE_RED= AE_RESET=
fi
# Banner header: cyan AEAntivirus branding.
ae_banner() {
  printf '%b\n' "${AE_CYAN}============================================================${AE_RESET}"
  printf '%b\n' "${AE_CYAN}  AEAntivirus${AE_RESET}${AE_DIM} - Linux protection setup${AE_RESET}"
  printf '%b\n' "${AE_CYAN}============================================================${AE_RESET}"
}
# Cyan section header.
ae_step()  { printf '%b%s%b\n' "$AE_CYAN" "--- $1 ---" "$AE_RESET"; }
# Green success line.
ae_ok()    { printf '%b%s%b\n' "$AE_GREEN" "[ok] $1" "$AE_RESET"; }
# Dim informational line.
ae_info()  { printf '%b%s%b\n' "$AE_DIM" "$1" "$AE_RESET"; }

# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
# API_HTTP holds the HTTP status of the last api_post call.
API_HTTP=0
# POST a JSON body read from stdin; echoes the response body. The URL is $1,
# extra curl args (e.g. -c/-b cookie-jar flags) follow. Secrets piped on
# stdin never touch disk.
api_post() {
  local url="$1"; shift
  local out http
  out=$(curl -sS -m 30 -X POST -H 'Content-Type: application/json' \
        --data @- "$@" "$url" -w '\n%{http_code}') || return 1
  http="${out##*$'\n'}"
  API_HTTP="$http"
  printf '%s' "${out%$'\n'*}"
}
# jget <json> <key> — print a string/number value ("" if missing). Never logs secrets.
jget() { python3 -c '
import json,sys
try: d=json.loads(sys.argv[1])
except Exception: sys.exit(1)
v=d.get(sys.argv[2],"")
print("" if v is None else (v if isinstance(v,str) else str(v)))
' "$1" "$2"; }
# jbool <json> <key> — exit 0 if the key is truthy.
jbool() { python3 -c '
import json,sys
try: d=json.loads(sys.argv[1])
except Exception: sys.exit(1)
sys.exit(0 if d.get(sys.argv[2]) else 1)
' "$1" "$2"; }
fail() { printf '%b%s%b\n' "$AE_RED" "ERROR: $*" "$AE_RESET" >&2; exit 1; }

# ---------------------------------------------------------------------------
# account collection (interactive prompts, env overrides for fleets)
# ---------------------------------------------------------------------------
collect_account() {
  local new_choice="${AEA_ACCOUNT_NEW:-}"
  if [ -z "$new_choice" ]; then
    echo
    echo "An AEAntivirus account is required to install — even a free one."
    echo "  1) Create a new free account"
    echo "  2) Sign in to an existing account"
    read -rp "Choose [1/2]: " new_choice
    case "$new_choice" in
      1|new|New|NEW|create) new_choice=new ;;
      2|existing|Existing|EXISTING|signin|sign-in) new_choice=existing ;;
      *) fail "please choose 1 (new account) or 2 (sign in)" ;;
    esac
  fi
  case "$new_choice" in
    new|existing) ;;
    *) fail "AEA_ACCOUNT_NEW must be 'new' or 'existing'" ;;
  esac
  AEA_ACCOUNT_NEW="$new_choice"

  AEA_ACCOUNT_EMAIL="${AEA_ACCOUNT_EMAIL:-}"
  if [ -z "$AEA_ACCOUNT_EMAIL" ]; then
    read -rp "Account email: " AEA_ACCOUNT_EMAIL
  fi
  [ -n "$AEA_ACCOUNT_EMAIL" ] || fail "an account email is required"

  if [ -z "${AEA_ACCOUNT_PASSWORD:-}" ]; then
    read -rsp "Account password: " AEA_ACCOUNT_PASSWORD; echo
  fi
  [ -n "${AEA_ACCOUNT_PASSWORD:-}" ] || fail "an account password is required"
}

# ---------------------------------------------------------------------------
# sign in (or create the free account), leaving the session in $JAR
# ---------------------------------------------------------------------------
auth_account() {
  local resp err
  # password travels via a pipe — never on the command line, never on disk
  json_acct() {
    AEA_ACCT_EMAIL="$AEA_ACCOUNT_EMAIL" AEA_ACCT_PW="$AEA_ACCOUNT_PASSWORD" \
      python3 -c 'import json,os; print(json.dumps(
        {"email": os.environ["AEA_ACCT_EMAIL"], "password": os.environ["AEA_ACCT_PW"]}))'
  }

  if [ "$AEA_ACCOUNT_NEW" = new ]; then
    ae_info "Creating your free AEAntivirus account..."
    resp=$(json_acct | api_post "$SERVER_URL/api/register-account" -c "$JAR") \
      || fail "could not reach the server at $SERVER_URL"
    if jbool "$resp" ok; then
      ae_ok "Account created and signed in."
    else
      err="$(jget "$resp" error)"; [ -n "$err" ] || err="account creation failed"
      case "$err" in
        *"already exists"*)
          fail "$err Run the installer again and choose sign-in (option 2)." ;;
      esac
      fail "$err"
    fi
  else
    ae_info "Signing in..."
    resp=$(json_acct | api_post "$SERVER_URL/api/login" -c "$JAR") \
      || fail "could not reach the server at $SERVER_URL"
    if ! jbool "$resp" ok; then
      # 2FA challenge: {ok:true, need_2fa:true, tfa_token:"..."}
      if jbool "$resp" need_2fa; then
        local tfa_token code resp2
        tfa_token="$(jget "$resp" tfa_token)"
        [ -n "$tfa_token" ] || fail "two-factor challenge was malformed"
        read -rp "Two-factor code: " code
        [ -n "$code" ] || fail "a two-factor code is required"
        resp2=$(AEA_TFA_TOKEN="$tfa_token" AEA_TFA_CODE="$code" \
          python3 -c 'import json,os; print(json.dumps(
            {"tfa_token": os.environ["AEA_TFA_TOKEN"], "code": os.environ["AEA_TFA_CODE"]}))' \
          | api_post "$SERVER_URL/api/login/2fa" -b "$JAR" -c "$JAR") \
          || fail "could not reach the server at $SERVER_URL"
        jbool "$resp2" ok || {
          err="$(jget "$resp2" error)"; [ -n "$err" ] || err="two-factor sign-in failed"
          fail "$err"
        }
        ae_ok "Signed in."
      else
        err="$(jget "$resp" error)"; [ -n "$err" ] || err="sign-in failed"
        fail "$err"
      fi
    else
      ae_ok "Signed in."
    fi
  fi
  # the password has served its purpose — drop it from the environment
  AEA_ACCOUNT_PASSWORD=; unset AEA_ACCOUNT_PASSWORD AEA_ACCT_PW
  unset -f json_acct
}

# ---------------------------------------------------------------------------
# activate this machine against the server using the signed-in session
# ---------------------------------------------------------------------------
activate_install() {
  local key
  if [ -z "${AEA_LICENSE_KEY+x}" ]; then
    # not provided at all -> ask; provided-but-empty -> trial, no prompt
    read -rp "License key (optional — blank starts a free 7-day trial on this account): " key
  else
    key="$AEA_LICENSE_KEY"
  fi
  ae_info "Activating this install..."
  local resp err
  resp=$(AEA_REG_KEY="$key" AEA_REG_HOST="$(hostname)" \
    AEA_REG_VER="$("$BIN" --version 2>/dev/null | sed -n 's/^AEAntivirus \([0-9.]*\).*/\1/p')" \
    python3 -c 'import json,os; print(json.dumps(
      {"license_key": os.environ.get("AEA_REG_KEY",""),
       "hostname": os.environ.get("AEA_REG_HOST","linux"),
       "version": os.environ.get("AEA_REG_VER",""),
       "platform": "linux"}))' \
    | api_post "$SERVER_URL/api/register" -b "$JAR") \
    || fail "could not reach the server at $SERVER_URL"
  if ! jbool "$resp" ok; then
    err="$(jget "$resp" error)"; [ -n "$err" ] || err="activation failed"
    case "$err" in
      account_required)
        fail "installation requires an AEAntivirus account — even a free one ($err)" ;;
    esac
    fail "activation failed: $err"
  fi
  local iid tok lkey lic exp tier seats
  iid="$(jget "$resp" install_id)"; tok="$(jget "$resp" token)"
  [ -n "$iid" ] && [ -n "$tok" ] || fail "server did not return install credentials"
  lkey="$(jget "$resp" license_key)"; lic="$(jget "$resp" license)"
  exp="$(jget "$resp" expires)"; tier="$(jget "$resp" tier)"
  seats="$(jget "$resp" max_installs)"
  "$BIN" --store-creds "$iid" "$tok" "$lkey" "$lic" "$exp" "$tier" "$seats" >/dev/null
  ae_ok "Activated (license: ${lic:-trial}, tier: ${tier:--})."
}

# ---------------------------------------------------------------------------
# main install flow
# ---------------------------------------------------------------------------
main() {
  if [ "$(id -u)" != "0" ]; then
    echo "Please run as root: sudo ./install.sh" >&2
    exit 1
  fi

  ae_banner

  # --- 1.34.2: Terms of Service + License Agreement acceptance (required) ---
  # Non-interactive: set AEA_ACCEPT_TOS=1 and AEA_ACCEPT_EULA=1 to pre-accept.
  AEA_SERVER_URL="${AEA_SERVER_URL:-https://aeantivirus.com}"
  accept_doc() {
    local name="$1" endpoint="$2" envvar="$3"
    local accepted="${!envvar:-}"
    if [ "$accepted" = "1" ]; then
      echo "[$name pre-accepted via $envvar=1]"
      return 0
    fi
    echo
    ae_step "$name"
    echo "Fetching from $AEA_SERVER_URL$endpoint ..."
    local text
    text=$(curl -sS -m 20 "$AEA_SERVER_URL$endpoint" 2>/dev/null) || text=""
    if [ -n "$text" ]; then
      echo "$text" | head -100
      echo "... (full text at $AEA_SERVER_URL$endpoint)"
    else
      echo "(Could not download — read the full text at $AEA_SERVER_URL$endpoint)"
    fi
    echo
    local ans
    read -rp "Do you accept the $name? [y/N]: " ans
    case "$ans" in
      y|Y|yes|YES) echo "Accepted."; return 0 ;;
      *) echo "You must accept the $name to install AEAntivirus. Aborting." >&2; exit 1 ;;
    esac
  }
  accept_doc "Terms of Service" "/api/terms-text" "AEA_ACCEPT_TOS"
  accept_doc "License Agreement" "/api/license-text" "AEA_ACCEPT_EULA"

  # --- dependencies ---
  if ! command -v curl >/dev/null 2>&1; then
    echo "curl is required but not installed. Install it first (apt install curl / yum install curl)." >&2
    exit 1
  fi
  if ! command -v python3 >/dev/null 2>&1; then
    echo "python3 is required but not installed. Install it first (apt install python3)." >&2
    exit 1
  fi
  if [ ! -f "$SRC_DIR/aeantivirusd" ]; then
    echo "aeantivirusd binary not found next to install.sh" >&2
    exit 1
  fi

  # --- install binary ---
  install -m 0755 "$SRC_DIR/aeantivirusd" "$BIN"
  ae_ok "installed $BIN"

  # --- systemd unit ---
  cat > "$UNIT" <<'EOF'
[Unit]
Description=AEAntivirus Protection Service
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/usr/local/bin/aeantivirusd --foreground
Restart=always
RestartSec=10
StartLimitInterval=0

[Install]
WantedBy=multi-user.target
EOF
  ae_ok "installed $UNIT"

  # --- data dirs ---
  mkdir -p /etc/aeantivirus /var/lib/aeantivirus/quarantine
  chmod 700 /etc/aeantivirus
  if [ -f "$SRC_DIR/signatures.db" ] && [ ! -f /var/lib/aeantivirus/signatures.db ]; then
    cp "$SRC_DIR/signatures.db" /var/lib/aeantivirus/signatures.db
  fi

  # --- configuration ---
  SERVER_URL="${AEA_SERVER_URL:-}"
  if [ -z "$SERVER_URL" ]; then
    read -rp "Server URL [https://aeantivirus.com]: " SERVER_URL
    SERVER_URL="${SERVER_URL:-https://aeantivirus.com}"
  fi
  "$BIN" --set-server "$SERVER_URL" >/dev/null

  # --- account (required) + activation ---
  # Session cookie jar: 0600, install lifetime only.
  JAR="$(mktemp)"; chmod 600 "$JAR"
  trap 'rm -f "$JAR"' EXIT
  collect_account
  auth_account
  activate_install
  # JAR is removed by the trap on exit

  # --- enable + start ---
  systemctl daemon-reload
  systemctl enable --now aeantivirus
  sleep 2
  systemctl --no-pager status aeantivirus | head -8 || true
  echo
  ae_ok "AEAntivirus installed and protecting this machine."
  ae_info "Check status any time with:  aeantivirusd --status"
}

# Allow the account/activation flow to be exercised by tests without
# running the full install:  AEA_INSTALL_SOURCED=1 . ./install.sh
if [ "${AEA_INSTALL_SOURCED:-}" != "1" ]; then
  main "$@"
fi
