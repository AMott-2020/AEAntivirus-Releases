# AEAntivirus 1.32.0 for Linux

## Router Guard host (Linux)

This daemon can act as its network's **Router Guard host** — the
Linux counterpart of the Windows client's router monitoring. The
server designates one main device per network (set in My Account);
the heartbeat tells the daemon whether it is that host
(`is_rg_host`) and whether the Router Guard add-on is active for
the account (`rg_entitled`).

- **Host duty.** When the daemon is both the host and entitled, it
  runs the full scored router audit — the same 11 checks, weights
  and plain-language wording as Windows (admin page security,
  Telnet, FTP/SSH, TR-069, extra admin ports, UPnP, ports open to
  the internet, DNS integrity, DHCP integrity, router
  identification) — first about two minutes after eligibility is
  learned, then about every 6 hours (±30 minutes of jitter). The
  audit rides the next heartbeat as `router_audit`; heartbeats
  without a fresh audit carry the top-level `gateway_key`
  (SHA-256 of the gateway MAC) so the per-network binding stays
  fresh.
- **Dormancy.** When the add-on is not active, or this device is
  not the network's main device, the daemon runs no periodic
  audits at all — one scanner per network, never congestion. A
  manual audit (below) still runs and posts; the server stores
  only a summary for unentitled accounts.
- **`routerguard-now`.** The admin "run now" command runs one audit
  on an entitled device and forces a heartbeat right after so it
  posts promptly; on an unentitled device it is logged and skipped.
- **CLI.** `aeantivirusd --router-guard-audit` runs one audit in
  the foreground, prints the audit JSON to stdout, and — when the
  daemon is registered — posts it on a heartbeat (marked
  `"manual":1` when this box is not the designated host).
  `aeantivirusd --router-guard-status` prints the last known host /
  entitlement state and the last audit's summary.
  `aeantivirusd --status` shows a one-line Router Guard summary too.
- **Netgear enrichment (minimal).** On a Netgear router that
  answers the NETGEAR Genie SOAP interface, the audit asks only for
  `DeviceInfo GetInfo` and uses its model/firmware as the audit's
  identity (adapter `netgear`); every other router is covered by
  the generic checks (adapter `generic`). Router credentials are
  read only from `etc/routerguard-netgear.conf` in the config dir
  (`user=` / `pass=` lines), and only when that file's permissions
  are 0600 or stricter; set it with
  `aeantivirusd --router-guard-netgear-set`, which reads the
  username and password as two lines from stdin (never argv) and
  writes the file 0600. The password is never logged and never
  appears in any JSON. The adapter's deeper checks (guest network,
  remote management) are not implemented on Linux yet, and no
  router setting is ever changed — the audit is read-only.

## New in 1.32.0

**AI Skills Checker.** The checker the Windows app has had since
1.38.6 (detection components since 2.5.119) arrives on Linux as
`aeantivirusd --ai-skills`. It verifies the AI Security Assistant in
order — add-on active on the account, AI service configured on the
server, daily questions remaining — from one status call that spends
no quota, then runs the two live tests (question answering, detection
explanation) and says up front that they use 2 of the day's
questions. Below that it lists this machine's detection components
with live status read from the real subsystems: the signature
database (count and set version), the heuristic scorer and its flag
threshold, the trained ML model (honestly "Not loaded — heuristic
scoring only" — Linux has no trained model), the ransomware canary,
the blocked-certificate list, the cached fleet-threat hashes, and a
live network-monitor snapshot. A self-test scores three built-in
samples on the device — a harmless text file, a synthetic
heuristic-trigger script, and the EICAR test string, which is
decoded and hash-checked in memory only and never written to disk —
and reports Pass or Fail per sample. Nothing is uploaded. Detection
reports now also remember the server's detection id
(`last_detection_id`), which is what the explanation live test asks
about — the same id the Windows client's per-detection Explain uses.

## New in 1.31.1

**DNS rebinding check + IPv6 globals.** The Router Guard audit gains
its 11th check, **DNS rebinding protection**: the daemon asks the
gateway's own DNS resolver for `rebind.aeantivirus.com` and warns if
the answer carries a private, loopback, or link-local address (an
empty or 0.0.0.0 answer passes; NXDOMAIN, a timeout, or a public-only
answer is N/A). Until that test name is switched on in DNS, the
check reports N/A on every audit — present and waiting, never a
guessed grade. The audit also reports the host's globally-routable
IPv6 addresses (`ipv6_globals`, 2000::/3 only, at most 8) so the
server's IPv6 outside-in WAN test can target exactly the addresses
this network reported — and no others.

## New in 1.31.0

**Router Guard host duty.** A Linux desktop designated as its network's
Router Guard main now runs the same universal 10-check gateway audit as
Windows (see "Router Guard host (Linux)" above): gateway fingerprint,
UPnP enumeration, DNS/DHCP checks and the gateway probe, posted on the
6-hour cadence, honoring the Router Guard add-on entitlement and admin
run-now commands. A saved Netgear sign-in identifies the router exactly;
the two deep Netgear checks and device block/allow stay on Windows
mains for now. Manual run: `aeantivirusd --router-guard-audit`.

## New in 1.30.1

**Form-factor reporting.** The daemon now reports its chassis form factor
(desktop / laptop / other, with the source of that reading) in its
heartbeat, the same as the Windows client, so Router Guard's per-network
main-device eligibility treats Linux desktops and laptops correctly.

## New in 1.30.0

**Six new Tech Tools network diagnostics.** A technician can now queue
six network checks that run on this device: **diag-netping** (gateway
and internet ping series with loss and jitter), **diag-dnsaudit**
(resolves test names through the system, gateway, and public resolvers
and flags disagreement), **diag-dhcp** (passive DHCP lease and
configuration audit, including the multi-gateway slice),
**diag-traceroute**, **diag-arpaudit** (duplicate-IP and suspicious
ARP-table audit), and **diag-speedtest** (download-only throughput
test against the AEAntivirus server). The Linux catalog is now 25
checks. These are per-device, on-demand diagnostics — Router Guard's
network-wide router monitoring is not in this build yet. (Superseded
by the Router Guard host section below: the network-wide monitoring
shipped in the next build.)

## New in 1.29.0

**Threat Guide lookup, a battery gate for scheduled scans, and faster
repeat scans.**

- **Threat Guide in the CLI:** `aeantivirusd --guide` lists the guide
  and `aeantivirusd --guide <slug>` prints one entry (name, severity,
  what it is, how it gets in, how AEAntivirus stops it); a detection
  name (e.g. `ML.Behavior.Ransomware`) prints that alert's plain-English
  explanation and, where the server data links one, the guide entry to
  read next. The data comes from the server's public
  `GET /api/threat-guide` — the same words the website renders, never a
  copy hardcoded in the client — is cached in the data dir, and works
  offline from the saved copy (the output says "from saved copy" when
  it does).
- **Scheduled scans wait for power:** a due scheduled scan now defers
  when the machine is *known* to be on battery (battery present, AC
  adapter read as offline) with charge below `schedscan_battery_min`
  percent (config, default 25; 0 disables). Unknown power state runs
  the scan; user-started scans never defer; machines with no battery
  are unaffected. A deferral never exceeds 24 hours (the start is
  persisted, so the cap holds across restarts), the scan stays due the
  whole time — it runs as soon as AC returns or the charge recovers,
  and at the cap it runs regardless. Deferrals are journaled like other
  scheduling events.
- **Faster repeat scans:** a file the full pipeline (signatures, fleet
  and certificate blocklists, ML heuristics) already judged clean is
  remembered by its SHA-256 in a persistent verdict cache, stamped with
  the signature-DB version that judged it. The cache is consulted only
  *after* the signature and blocklist stages, so a remembered file can
  never hide a detection — and a signature update expires every cached
  verdict at once. `--status` and the scan log lines show the count as
  **Skipped (unchanged)**. The offline `--rescue-scan` mode never
  consults or writes the cache: rescue scans of foreign media stay
  exhaustive.
- Not applicable to the Linux daemon (a headless service): the Windows
  wave's fullscreen/game-mode hold (no desktop session concept here —
  the battery gate above is the scheduled-scan hold this platform
  gets), its text-size setting (no GUI), and delta installer patches
  (the Linux channel stays a full tarball download).

## New in 1.28.0

**Rescue scan mode.** The daemon gains an offline one-shot mode built
for the Rescue scan USB (see `rescue/` in this repo):
`aeantivirusd --rescue-scan <target-dir> --sigs <db> --quarantine-dir <dir> --report <file>`.
It never initialises the cloud reporter and needs no credentials, no
daemon, and no network: it walks the target with the same scan engine,
MOVES anything it detects into the quarantine dir preserving the
file's relative path (never deletes), and writes a plain-text report
(header, one line per hit, counts summary). The signature DB given on
the command line is authoritative for the run. Exit 0 on completion,
2 on bad arguments or a missing target.

## New in 1.27.0

**Tech tools diagnostics.** The daemon now runs the 19 read-only
diagnostic checks its platform can answer honestly — health, system
spec, hardware inventory, drive check, drive reliability (SMART via
smartctl only when the box has it; the fields are "not reported",
never invented, when it does not), disk space (with a real percent —
the only check that has one), battery (a machine with no battery
answers "none", like a desktop), connectivity, clock & time sync,
temperatures (hwmon), services health, user accounts, installed
programs (dpkg/rpm), event log digest (journal, 7 days), crash
history, startup items, network adapters, security posture
(firewall, sshd password authentication and root login from the
config files), and boot performance (systemd-analyze). Checks are
queued from the admin panel like on Windows, journal to syslog,
report progress stages, honor diag-cancel (running or queued), and
never bill when they error or are cancelled. The Windows-only
checks (system file verification, Windows Update, BitLocker,
activation, and the rest of the Windows catalog) are not offered
for Linux devices — the server refuses them with the reason.

Real-time antivirus daemon for Linux servers and desktops. Watches your
`Downloads`/`Desktop` folders (plus `/tmp`), scans on demand, quarantines
threats, and reports to your AEAntivirus server.

## Install

```sh
sudo ./install.sh
```

The installer asks for your server URL and your AEAntivirus account — every
install needs an account, even a free one. Choose "create a new free
account" or "sign in"; the installer activates the machine with your
session (a blank license key starts a free 7-day trial on that account).
Fleet installs can pass everything non-interactively:

```sh
sudo AEA_SERVER_URL=https://av.example.com \
     AEA_ACCOUNT_NEW=new AEA_ACCOUNT_EMAIL=you@example.com \
     AEA_ACCOUNT_PASSWORD='s3cret-passphrase' \
     AEA_LICENSE_KEY=AEA-XXXX ./install.sh
```

This installs `aeantivirusd` to `/usr/local/bin` and enables the
`aeantivirus` systemd service. Requires `curl` and systemd.

## Usage

```sh
aeantivirusd --status              # license, plan, protection state
aeantivirusd --scan-quick          # scan Downloads/Desktop everywhere
aeantivirusd --scan-full           # scan the whole filesystem
aeantivirusd --scan /path          # scan one file or folder
aeantivirusd --guide               # list the Threat Guide (cached for offline use)
aeantivirusd --guide ransomware    # look up one entry / alert explanation
aeantivirusd --quarantine-list     # show quarantined items
aeantivirusd --quarantine-restore <id>
aeantivirusd --quarantine-delete <id>
aeantivirusd --set-key AEA-XXXX    # change license key (re-registers)
aeantivirusd --set-server https://av.example.com
aeantivirusd --heartbeat          # force a server check-in
aeantivirusd --check-update        # pull new signatures / engine
aeantivirusd --version
```

## How it works

- **Real-time:** inotify watches fire on new/changed files; hits are
  quarantined instantly and reported to the server.
- **Detection:** SHA-256 / MD5 / SHA-1 signature database (v4 rows carry
  all three hashes; includes the EICAR test file under each), a
  code-signing certificate blocklist (`certs.db`, checked against
  Authenticode signatures in PE files), plus heuristics for double
  extensions (`invoice.pdf.exe`), suspicious scripts, and suspicious
  ELF binaries.
- **Quarantine:** threats are moved to `/var/lib/aeantivirus/quarantine`
  (mode 0600) with a `.meta` sidecar; restore or delete from the CLI.
- **Licensing:** the daemon registers with your server, heartbeats
  regularly, and pauses real-time protection if the license lapses or the
  server policy disables it.
- **Config:** `/etc/aeantivirus/` (mode 0700). Override the base dir for
  testing with `AEA_BASE=/tmp/xyz`.

## New in 1.26.0

- **Family quiet hours: ENFORCED — via a managed /etc/hosts block.**
  The daemon still has no DNS filter, so enforcement is at name
  resolution: while a quiet-hours window is active, the daemon
  writes a marker-delimited managed section into `/etc/hosts` that
  resolves the quiet-hours categories (social, gaming, streaming —
  the same lists and the same window semantics as Windows and
  Android: start-inclusive, end-exclusive, an overnight window
  belongs to the day it starts, malformed windows fail open) to
  127.0.0.1 and ::1, apex names plus their `www.` hosts. The
  section is removed when the window ends, the policy turns off,
  the license lapses, and on clean daemon shutdown. `--status`
  reports the live state (ENFORCING / window not active / CANNOT
  ENFORCE with the reason) instead of assuming it. Safety, stated
  plainly: the original hosts file is backed up to
  `/var/lib/aeantivirus/hosts-backup` before the first edit and no
  edit happens without it; writes are atomic; only our section is
  ever rewritten — everything else is preserved byte-for-byte (a
  file with no trailing newline gains one — the separator the
  section needs); aeantivirus.com, localhost and the machine's own
  hostname can never be blocked; and before any write, the block
  list must pass a self-check against the category tables. Limits,
  also plainly: hosts files have no wildcards, so only the listed
  names and their `www.` hosts are covered — other subdomains are
  not; this is domain-level blocking, not per-app; and because the
  block lives in the hosts file, the daemon cannot see individual
  lookups, so Linux quiet-hours blocks do not produce per-block
  events for the family digest the way Windows/Android do. There
  is no uninstaller in install.sh; `systemctl stop` reaches the
  same shutdown path that removes the block. Proven in
  `v1260-test.sh`: the Windows 29-case window matrix against the
  ported code, hosts-surgery tests, and a live daemon end-to-end
  (block written, status ENFORCING, SIGTERM restores the file
  byte-for-byte, unreachable hosts path reports CANNOT ENFORCE).
- (1.25.0's "delivered, NOT enforced" note below is superseded by
  this release; it is kept as the record of what 1.25.0 did.)

## New in 1.25.0

- **Signature delta updates.** The daemon now consumes the same
  hash-chained delta format the server publishes for Windows
  (`server/lib/sigdelta.js`, AESIGDELTA): on an update it walks
  `sigs-chain.json` from its current version to the manifest's,
  verifying every delta's own SHA-256, every step's result hash, and
  finally the manifest's full-database hash — all in memory — and
  only then writes the rebuilt database to `signatures.db.new`,
  re-verifies it on disk, and atomically renames it into place. Any
  failure (missing step, hash mismatch, unappliable delta) is logged
  with its reason and falls back to the full download, exactly as
  before; the on-disk database is never touched by a failed chain.
  Proven end-to-end in `v1250-test.sh`: the compiled daemon updates
  v37 → v38 from the shipped chain artifacts without fetching the
  full database, and a corrupted delta produces the journaled
  fallback. The engine itself is byte-identical to the Windows port
  on the server oracle's fixtures and the shipped chain.
- **Family quiet hours: delivered, NOT enforced — stated plainly.**
  The daemon now receives the `policy_quiet_hours_*` policy on the
  heartbeat and stores it (see `--status`). But the Linux daemon has
  **no DNS filter and no domain-blocking surface of any kind** —
  quiet hours work by pausing web categories, and there is nothing
  here that could pause them. Rather than pretend otherwise, the
  daemon logs the policy as "noted; not enforced on Linux" and
  `--status` says the same. Quiet hours are enforced on Windows and
  Android, where the DNS filter lives. (The paused-subscription
  behavior from 1.24.0 is unchanged and re-guarded in the suite.)
- Tests: `v1250-test.sh` + `v1250-e2e.js` — engine oracle fixtures,
  shipped-chain cross-check, chain walk, full daemon compile, and a
  live end-to-end against a local docroot (delta path, journaled
  fallback, quiet-hours delivery).

## New in 1.24.0

- **Subscription pause parity (with Windows client 2.5.123).** When the
  server reports the license as `paused` (a billing pause window),
  protection is OFF for the whole window — realtime monitoring stops —
  with a distinct "subscription paused until <date>" log line and a
  matching `--status` note. There is **no 72-hour grace for a pause**
  (grace belongs to past-due); protection returns by itself when the
  window ends.
- **`reset-stats` command.** The daemon now honors the server's
  reset-stats command (queued from the admin panel or the customer's
  account page since server 2.5.144): the local scanned/detected
  counters zero and persist. Quarantine contents and records are never
  touched by a reset, and last-scan times stay — same scope as the
  Windows client's local reset.
- Tests: `v1240-test.sh` — unit checks for the paused decision and the
  reset values, the full daemon compile check, and source guards.

## New in 1.23.1

- **Quarantine moves now work across filesystems.** Quarantining and
  restoring used bare `rename()` calls, which fail with EXDEV whenever
  the file and the quarantine folder live on different filesystems —
  most commonly a threat found in `/tmp` when the data dir is on
  another mount, so the file was detected but never actually moved
  (the same bug class fixed on Windows in client 2.5.117). Both moves
  now go through a `move_file()` helper: rename first, and on failure
  a chunked copy whose size is verified against the source before the
  source is removed. A failed move removes the partial copy and leaves
  the original untouched — nothing is lost and success is never
  reported for a file that did not move.
- **Verified end to end** against a locally booted 2.5.138 server:
  clean install via `install.sh`, the service registers and heartbeats
  as platform **linux** (server 2.5.138 fixed the server side of that),
  an EICAR file dropped in `/tmp` was detected, actually quarantined
  (present in the quarantine store and in `--quarantine-list`), and
  restored byte-for-byte.

## New in 1.23.0

- **Packaging release — no new features.** This is the first downloadable
  tarball built from the 1.22.0 engine: fleet threat-intelligence sharing
  (a hash confirmed on any fleet device is blocked on sight via the fleet
  blocklist, checked before heuristics) and the ML weighted-scoring engine
  (~40 signals: ELF anomalies, suspicious content, script analysis, and
  network/exfiltration signals; score ≥ 65 quarantines). Both shipped in
  source as 1.22.0 but were never packaged — the previously published
  tarball and manifest were still 1.21.0. The 1.23.0 tarball now matches
  the source.
- **Verified end to end.** The daemon was rebuilt from the current source
  and verified against a live server: registration with a license key,
  heartbeat (server shows platform linux, version 1.23.0), `--status`
  consistent with the server, and EICAR detection/quarantine. The
  `v1200-test.sh` daemon compile check now includes `fleetblock.c` and
  `mlheur.c` (it predated them and failed to link the 1.22.0+ daemon);
  two latent 1.22.0 build bugs were fixed along the way (`mlheur.c` used
  `memmem()` without `_GNU_SOURCE`, and the link was missing `-lm`).

## New in 1.22.0

- **Fleet threat intelligence.** A hash confirmed as a threat on any fleet
  device is shared with the fleet; the daemon pulls the fleet IOC list
  (throttled) and blocks matching files on sight, before heuristics.
- **ML weighted scoring.** A ~40-signal weighted ML engine ported from
  Windows — ELF anomaly detection, suspicious content signals, script
  analysis, and network/exfiltration signals. Score ≥ 65 quarantines.

## New in 1.20.0

- **Remote support screen streaming (X11).** When a support session is
  started from the admin console, the daemon polls the server's
  `/api/commands` queue every 30 seconds and honors `remote-start:<id>`
  / `remote-stop`. On start it opens a WebSocket to
  `/api/remote/stream` (same install credentials as the heartbeat, TLS
  with certificate + hostname verification), sends a
  `{"t":"hello","platform":"linux",...}` greeting, then streams JPEG
  screen frames (~4 fps, each capped at 512 KB, adaptive quality) while
  relaying the agent's mouse/keyboard input via the XTest extension.
  Capture uses X11 shared memory (XShm) with a plain-XGetImage
  fallback; a persistent topmost banner reading "A support agent is
  connected" stays visible for the whole session with a clickable
  Disconnect button. Streaming runs on its own thread and never blocks
  protection; unexpected drops retry 3 times (5 s apart) before giving
  up. Sessions start only on a server command — never automatically.
- **Honest platform limits.** X11, Xext, Xtst and libjpeg are loaded at
  runtime, so headless servers without X libraries keep running the
  daemon unaffected; remote streaming is simply reported unavailable.
  **Wayland sessions are not supported** — there is no unattended screen
  capture API for a daemon under Wayland, so the daemon logs the
  limitation and refuses to stream rather than faking it.
- Covered by `v1200-test.sh` (87 checks: message parsing incl. malformed
  rejection, frame cap, DOM-code to keysym mapping, RFC 6455 vectors,
  JPEG encoding, Wayland detection) plus a full-daemon compile check.

## New in 1.19.0

- **Network monitor reporting.** The daemon now collects a summarized
  network snapshot every 60 seconds and POSTs it to the server's
  `/api/netstats` endpoint for the admin panel's fleet view: per-process
  connection counts with up/down byte totals and rates, the top
  connections (process, protocol, local/remote `ip:port`, TCP state),
  and total interface traffic. Collection parses
  `/proc/net/tcp{,6}`/`udp{,6}`, maps sockets to PIDs via
  `/proc/<pid>/fd`, and reads per-connection byte counters from
  `/proc/net/nf_conntrack` when present (fail-open without it).
  Summarized stats only — no packet payloads, no URLs. Reporting is
  fail-open with backoff: a dead server is logged once per attempt and
  never retry-storms, and the daemon keeps protecting locally.
- New `aeantivirusd --netstats` sends one snapshot immediately.

## New in 1.18.0

- **Account required to install.** Every install now needs an AEAntivirus
  account — even a free one. The installer signs you in (or creates a free
  account) and activates the machine with that session; anonymous installs
  are refused by the server (`account_required`). A blank license key still
  starts a free 7-day trial, now tied to the installing account.
- The daemon fails safe without cloud features if the server ever demands
  an account mid-run — local scanning keeps working, and it never
  retry-storms the registration endpoint.

## Scheduled scans and ransomware canary (1.16.0)

- **Scheduled full-system scans** (opt-in): add to `/etc/aeantivirus/config`
  ```ini
  schedscan=1
  schedscan_time=02:00    # 24-hour local time, default 02:00
  schedscan_freq=weekly   # daily or weekly, default weekly
  ```
  The daemon runs a full scan on that schedule (checked once a minute;
  same-day catch-up if the machine was off at the scheduled time).
- **Ransomware canary tripwire** (on by default): the daemon plants hidden
  decoy files (three in `/var/lib/aeantivirus/canary/`, one in `/tmp`, one
  in each user's home) and re-hashes them every 60 seconds. If 3 or more
  change within 5 minutes it reports `Ransomware.Behavior.Canary` to the
  server and terminates exactly the processes holding a decoy file open
  (never PID 1, never itself). Disable with `canary=0`; alert-only mode
  with `canary_kill=0`.
- `aeantivirusd --status` shows both features' on/off state.

## Files in this package

- `aeantivirusd` — the compiled daemon (x86-64)
- `install.sh` — root installer (systemd service setup)
- `README.md` — this file

Service logs: `journalctl -u aeantivirus`.
